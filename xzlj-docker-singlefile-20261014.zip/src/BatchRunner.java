import java.awt.geom.Area;
import java.awt.geom.Path2D;
import java.awt.geom.PathIterator;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.Collections;
import java.util.Comparator;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Set;

/**
 * 线上批量入口：一次建立小中场景点姿态采样缓存，再并行生成全部场景方案。
 * 用法：java -cp algorithm.jar BatchRunner [dataDir] [outputDir] [workers] [smallSeconds] [largeSeconds] [seed]
 */
public final class BatchRunner {
    private BatchRunner() {
    }

    public static void main(String[] args) throws Exception {
        Path dataDir = args.length > 0 ? Paths.get(args[0]) : Paths.get("/data");
        Path outputDir = args.length > 1 ? Paths.get(args[1]) : dataDir.resolve("results");
        int workers = args.length > 2 ? Integer.parseInt(args[2])
                : Math.max(2, Math.min(8, Runtime.getRuntime().availableProcessors() / 6));
        int smallSeconds = args.length > 3 ? Integer.parseInt(args[3]) : 5;
        int largeSeconds = args.length > 4 ? Integer.parseInt(args[4]) : 1;
        long seed = args.length > 5 ? Long.parseLong(args[5]) : 20260822L;
        if (workers < 1 || smallSeconds < 1 || largeSeconds < 1) {
            throw new IllegalArgumentException("workers和搜索时间必须为正数");
        }
        List<String> scenarios = listScenarios(dataDir.resolve("scenarios"));
        int discoveredScenarioCount = scenarios.size();
        String selected = System.getProperty("xzlj.scenarios", "");
        int expectedScenarioCount = Integer.getInteger("xzlj.expectedScenarioCount", 60);
        if (expectedScenarioCount < 1) {
            throw new IllegalArgumentException("xzlj.expectedScenarioCount必须为正数");
        }
        if (selected.isBlank() && scenarios.size() != expectedScenarioCount) {
            throw new IllegalStateException("完整批跑要求场景数=" + expectedScenarioCount
                    + "，实际发现=" + scenarios.size() + "；拒绝生成不完整方案集");
        }
        if (!selected.isBlank()) {
            List<String> requested = List.of(selected.split(","));
            List<String> unknown = new ArrayList<>(requested);
            unknown.removeAll(scenarios);
            if (!unknown.isEmpty()) {
                throw new IllegalArgumentException("指定的场景不存在：" + unknown);
            }
            scenarios.removeIf(scenario -> !requested.contains(scenario));
        }
        if (scenarios.isEmpty()) {
            throw new IllegalStateException("没有找到可运行的场景");
        }
        System.out.printf(Locale.ROOT, "输入预检通过：数据目录=%s，发现=%d，计划运行=%d%n",
                dataDir.toAbsolutePath(), discoveredScenarioCount, scenarios.size());
        Files.createDirectories(outputDir);

        long started = System.nanoTime();
        GreedyAlgorithm.main(new String[]{"--prepare-cache", dataDir.toString()});
        System.out.printf(Locale.ROOT,
                "批量运行：场景=%d，workers=%d，小/中搜索=%ds，大搜索=%ds，输出=%s%n",
                scenarios.size(), workers, smallSeconds, largeSeconds, outputDir.toAbsolutePath());

        ExecutorService pool = Executors.newFixedThreadPool(workers);
        List<Future<Result>> futures = new ArrayList<>();
        for (String scenario : scenarios) {
            int taskCount = Integer.parseInt(scenario.substring(scenario.indexOf('-') + 1));
            int seconds = taskCount <= 3000 ? smallSeconds : largeSeconds;
            futures.add(pool.submit(new ScenarioRun(scenario, dataDir, outputDir, seconds, seed)));
        }
        pool.shutdown();

        int success = 0;
        for (Future<Result> future : futures) {
            try {
                Result result = future.get();
                if (result.success) success++;
                System.out.printf(Locale.ROOT, "BATCH_RESULT scenario=%s status=%s elapsedSeconds=%.3f%n",
                        result.scenario, result.success ? "SUCCESS" : "FAILED", result.elapsedSeconds);
            } catch (InterruptedException interrupted) {
                Thread.currentThread().interrupt();
                throw interrupted;
            } catch (ExecutionException failed) {
                System.err.println("场景执行失败：" + failed.getCause());
            }
        }
        double elapsed = (System.nanoTime() - started) / 1_000_000_000.0;
        List<String> missingOutputs = new ArrayList<>();
        for (String scenario : scenarios) {
            Path result = outputDir.resolve(scenario + ".csv");
            if (!Files.isRegularFile(result) || Files.size(result) == 0) {
                missingOutputs.add(scenario + ".csv");
            }
        }
        int failed = scenarios.size() - success;
        System.out.printf(Locale.ROOT,
                "BATCH_SUMMARY success=%d failed=%d missingCsv=%d wallSeconds=%.3f%n",
                success, failed, missingOutputs.size(), elapsed);
        if (!missingOutputs.isEmpty()) {
            System.err.println("缺少或为空的方案文件：" + missingOutputs);
        }
        if (success != scenarios.size() || !missingOutputs.isEmpty()) {
            throw new IllegalStateException("存在场景未成功输出完整方案集");
        }
    }

    private static List<String> listScenarios(Path scenariosDir) throws IOException {
        List<String> result = new ArrayList<>();
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(scenariosDir)) {
            for (Path path : stream) {
                if (Files.isDirectory(path) && path.getFileName().toString().matches("\\d+-\\d+")) {
                    result.add(path.getFileName().toString());
                }
            }
        }
        result.sort(Comparator.comparingInt(BatchRunner::satelliteCount)
                .thenComparingInt(BatchRunner::taskCount));
        return result;
    }

    private static int satelliteCount(String scenario) {
        return Integer.parseInt(scenario.substring(0, scenario.indexOf('-')));
    }

    private static int taskCount(String scenario) {
        return Integer.parseInt(scenario.substring(scenario.indexOf('-') + 1));
    }

    private record Result(String scenario, boolean success, double elapsedSeconds) {
    }

    private static final class ScenarioRun implements Callable<Result> {
        private final String scenario;
        private final Path dataDir;
        private final Path outputDir;
        private final int seconds;
        private final long seed;

        ScenarioRun(String scenario, Path dataDir, Path outputDir, int seconds, long seed) {
            this.scenario = scenario;
            this.dataDir = dataDir;
            this.outputDir = outputDir;
            this.seconds = seconds;
            this.seed = seed;
        }

        @Override
        public Result call() throws Exception {
            Path output = outputDir.resolve(scenario + ".csv");
            Files.deleteIfExists(output);
            Files.deleteIfExists(outputDir.resolve(scenario + "-alns.csv"));
            long started = System.nanoTime();
            try {
                ImprovedALNS.main(new String[]{scenario, dataDir.toString(), outputDir.toString(),
                        Integer.toString(seconds), Long.toString(seed)});
                if (Files.isRegularFile(output) && Files.size(output) > 0) {
                    return new Result(scenario, true, (System.nanoTime() - started) / 1_000_000_000.0);
                }
                throw new IOException("ALNS未生成有效输出文件: " + output);
            } catch (Exception | LinkageError failed) {
                System.err.println("场景 " + scenario + " 的ALNS失败，切换贪心兜底：" + failed);
                try {
                    GreedyAlgorithm.main(new String[]{scenario, dataDir.toString(), outputDir.toString()});
                    boolean recovered = Files.isRegularFile(output) && Files.size(output) > 0;
                    if (!recovered) {
                        System.err.println("场景 " + scenario + " 的贪心兜底也未生成有效输出");
                    }
                    return new Result(scenario, recovered,
                            (System.nanoTime() - started) / 1_000_000_000.0);
                } catch (Exception | LinkageError fallbackFailed) {
                    System.err.println("场景 " + scenario + " 的贪心兜底失败：" + fallbackFailed);
                    return new Result(scenario, false,
                            (System.nanoTime() - started) / 1_000_000_000.0);
                }
            }
        }
    }
}

/**
 * 单文件 Java 贪心基线。
 *
 * 用法：
 *   java App                         # 从当前目录或父目录寻找 data，运行 10-300
 *   java App 10-300                  # 指定场景
 *   java App 10-300 D:/project/data  # 指定场景和 data 目录
 *
 * 程序只使用 JDK 标准库，并按修订版规则输出“观测-数传”相邻行。
 */
final class GreedyAlgorithm {
    private static final long TX_SWITCH_GAP = 20L;
    private static final Pattern COORD_PAIR = Pattern.compile("\\[\\s*(-?\\d+(?:\\.\\d+)?)[,，]\\s*(-?\\d+(?:\\.\\d+)?)\\s*\\]");

    public static void main(String[] args) throws Exception {
        if (args.length > 0 && "--prepare-cache".equals(args[0])) {
            Path dataDir = args.length > 1 ? Paths.get(args[1]) : findDataDir();
            Repository.preparePointAttitudeCache(dataDir, 32);
            return;
        }
        String scenarioName = args.length > 0 && !args[0].isBlank() ? args[0] : "10-300";
        Path dataDir = args.length > 1 ? Paths.get(args[1]) : findDataDir();
        Path outputDir = args.length > 2 ? Paths.get(args[2]) : dataDir.resolve("results");
        Files.createDirectories(outputDir);
        System.out.println("=== 遥感星群多约束任务规划：Java 贪心基线 ===");
        System.out.println("data=" + dataDir.toAbsolutePath());
        System.out.println("scenario=" + scenarioName);
        Repository repo = new Repository(dataDir);
        repo.loadBase(scenarioName);
        Scenario scenario = repo.loadScenario(scenarioName);
        System.out.printf(Locale.ROOT, "资源卫星=%d，点任务=%d，区域任务=%d%n", scenario.resources.size(), scenario.pointTasks.size(), scenario.areaTasks.size());
        GreedySolver solver = new GreedySolver(repo, scenario);
        Schedule schedule = solver.solve();
        Path output = outputDir.resolve(scenarioName + ".csv");
        writeSchedule(output, schedule);
        ValidationReport report = validate(schedule, repo, scenario);
        System.out.printf(Locale.ROOT, "候选：点任务有候选=%d/%d，区域任务有候选=%d/%d%n", solver.pointWithCandidates, scenario.pointTasks.size(), solver.areaWithCandidates, scenario.areaTasks.size());
        System.out.printf(Locale.ROOT, "结果：观测=%d，数传=%d，完成主任务=%d，估算收益=%.2f%n", schedule.observations.size(), schedule.transmissions.size(), schedule.completedTaskIds.size(), schedule.estimatedScore);
        System.out.printf(Locale.ROOT, "检查：约束违规计数=%d（%s）%n", report.totalViolations, report.summary());
        System.out.println("已写出：" + output.toAbsolutePath());
    }

    static Path findDataDir() {
        List<Path> candidates = List.of(Paths.get("data"), Paths.get("..", "data"), Paths.get("..", "..", "data"), Paths.get("C:/Users/Administrator/Desktop/新智砺剑赛题四数据集/data"));
        for (Path p : candidates) if (Files.isDirectory(p.resolve("scenarios")) && Files.exists(p.resolve("satellites.csv"))) return p.normalize();
        throw new IllegalArgumentException("找不到 data 目录，请通过第二个参数显式传入 data 路径");
    }

    static void writeSchedule(Path output, Schedule schedule) throws IOException {
        try (BufferedWriter w = Files.newBufferedWriter(output, StandardCharsets.UTF_8)) {
            w.write("satellite_id,taskId,station,start_time,end_time,roll_angle,pitch_angle\n");
            for (int i = 0; i < schedule.observations.size(); i++) {
                Observation o = schedule.observations.get(i); Transmission t = schedule.transmissions.get(i);
                w.write(csv(o.satelliteId) + "," + csv(o.taskId) + ",," + o.start + "," + o.end + "," + fmt(o.roll) + "," + fmt(o.pitch) + "\n");
                w.write(csv(t.satelliteId) + "," + csv(t.taskId) + "," + csv(t.station) + "," + t.start + "," + t.end + ",,\n");
            }
        }
    }
    private static String csv(String s) { return s == null ? "" : (s.contains(",") || s.contains("\"") ? "\"" + s.replace("\"", "\"\"") + "\"" : s); }
    private static String fmt(double d) { return String.format(Locale.ROOT, "%.6f", d); }

    static final class Repository {
        final Path data; final Map<String, Satellite> satellites = new LinkedHashMap<>(); final Map<String, List<Arc>> arcsBySatellite = new HashMap<>();
        final Map<String, List<PointWindow>> pointWindows = new HashMap<>(); final Map<String, List<AreaWindow>> areaWindows = new HashMap<>();
        final Map<String, List<Attitude>> pointAttitudes = new HashMap<>(); final Map<String, List<Attitude>> areaAttitudes = new HashMap<>();
        final Map<String, Point> pointTargets = new HashMap<>(); final Map<String, Polygon> areaTargets = new HashMap<>(); final Set<String> requestedPointWindowIds = new HashSet<>(); final Set<String> requestedAreaWindowIds = new HashSet<>();
        Repository(Path data) { this.data = data; }

        void loadBase(String scenarioName) throws IOException {
            loadSatellites(data.resolve("satellites.csv"));
            Scenario raw = readScenarioFiles(scenarioName);
            loadArcs(data.resolve("arcs.csv"), raw.resources);
            loadPointWindows(data.resolve("vtw/points_vtws.csv"), raw.resources, raw.pointTargetIds());
            loadAreaWindows(data.resolve("vtw/areas_vtws.csv"), raw.resources, raw.areaTargetIds());
            for (List<PointWindow> xs : pointWindows.values()) for (PointWindow x : xs) requestedPointWindowIds.add(x.windowId);
            for (List<AreaWindow> xs : areaWindows.values()) for (AreaWindow x : xs) requestedAreaWindowIds.add(x.windowId);
            int taskCount = raw.taskById.size();
            String configuredPointLimit = System.getProperty("xzlj.pointWindowLimit");
            int pointWindowLimit;
            if (configuredPointLimit != null) {
                int value = Integer.parseInt(configuredPointLimit);
                pointWindowLimit = value < 0 ? Integer.MAX_VALUE : value;
            } else {
                pointWindowLimit = taskCount <= 3_500 ? 32
                        : taskCount <= 10_000 ? 12 : 8;
            }
            loadAttitudes(data.resolve("vtw/points_vtws_attitudes.csv"), true, pointWindowLimit);
            loadAttitudes(data.resolve("vtw/areas_vtws_attitudes.csv"), false, Integer.MAX_VALUE);
            loadPointTargets(data.resolve("targets/points.csv"), raw.pointTargetIds());
            loadAreaTargets(data.resolve("targets/areas.csv"), raw.areaTargetIds());
        }
        Scenario loadScenario(String name) throws IOException { return readScenarioFiles(name); }
        private Scenario readScenarioFiles(String name) throws IOException {
            Path dir = data.resolve("scenarios").resolve(name); if (!Files.isDirectory(dir)) throw new IOException("场景目录不存在: " + dir);
            Scenario s = new Scenario(name);
            try (BufferedReader r = Files.newBufferedReader(dir.resolve("resource.csv"), StandardCharsets.UTF_8)) { r.readLine(); String line; while ((line = r.readLine()) != null) if (!line.isBlank()) s.resources.add(unquote(line.trim())); }
            readTasks(dir.resolve("task-p.csv"), s.pointTasks, TaskType.POINT); readTasks(dir.resolve("task-a.csv"), s.areaTasks, TaskType.AREA);
            for (Task t : s.pointTasks) s.taskById.put(t.id, t); for (Task t : s.areaTasks) s.taskById.put(t.id, t); return s;
        }
        private void loadSatellites(Path file) throws IOException {
            try (BufferedReader r = Files.newBufferedReader(file, StandardCharsets.UTF_8)) { r.readLine(); String line; while ((line = r.readLine()) != null) {
                if (line.isBlank()) continue; List<String> c = splitCsv(line); if (c.size() < 16) continue; Satellite s = new Satellite();
                s.id=c.get(0); s.type=c.get(1).toLowerCase(Locale.ROOT); s.rollMin=dbl(c,3); s.rollMax=dbl(c,4); s.pitchMin=dbl(c,5); s.pitchMax=dbl(c,6); s.maxOffNadir=dbl(c,7); s.minAbsRoll=dbl(c,8); s.solarReq=dbl(c,9); s.resolution=dbl(c,10); s.minWork=lng(c,11); s.maxOrbitWork=lng(c,12); s.slewSpeed=dbl(c,13); s.sameSideSlew=lng(c,14); s.oppSideSlew=lng(c,15); satellites.put(s.id,s);
            }}
        }
        private void loadArcs(Path file, Set<String> resources) throws IOException {
            try (BufferedReader r = Files.newBufferedReader(file, StandardCharsets.UTF_8)) { r.readLine(); String line; while ((line=r.readLine()) != null) { List<String> c=splitCsv(line); if(c.size()<4||!resources.contains(c.get(0)))continue; Arc a=new Arc(c.get(0),c.get(1),utc(c.get(2)),utc(c.get(3))); arcsBySatellite.computeIfAbsent(a.satelliteId,k->new ArrayList<>()).add(a); }}
            for(List<Arc> xs:arcsBySatellite.values()) xs.sort(Comparator.comparingLong(a->a.start));
        }
        private void loadPointWindows(Path file, Set<String> resources, Set<String> targets) throws IOException {
            try(BufferedReader r=Files.newBufferedReader(file,StandardCharsets.UTF_8)){r.readLine();String line;while((line=r.readLine())!=null){List<String> c=splitCsv(line);if(c.size()<8||!resources.contains(c.get(1))||!targets.contains(c.get(2)))continue;PointWindow x=new PointWindow(c.get(0),c.get(1),c.get(2),utc(c.get(3)),utc(c.get(4)));pointWindows.computeIfAbsent(key(x.satelliteId,x.targetId),k->new ArrayList<>()).add(x);}}
        }
        private void loadAreaWindows(Path file, Set<String> resources, Set<String> targets) throws IOException {
            try(BufferedReader r=Files.newBufferedReader(file,StandardCharsets.UTF_8)){r.readLine();String line;while((line=r.readLine())!=null){List<String> c=splitCsv(line);if(c.size()<8||!resources.contains(c.get(1))||!targets.contains(c.get(2)))continue;AreaWindow x=new AreaWindow(c.get(0),c.get(1),c.get(2),utc(c.get(4)),utc(c.get(5)));areaWindows.computeIfAbsent(key(x.satelliteId,x.targetId),k->new ArrayList<>()).add(x);}}
        }
        private void loadAttitudes(Path file, boolean point, int perWindowLimit) throws IOException {
            Set<String> needed = point ? requestedPointWindowIds : requestedAreaWindowIds;
            Map<String, List<Attitude>> destination = point ? pointAttitudes : areaAttitudes;
            List<AttitudeRange> ranges = loadNeededRanges(file, needed);
            ranges.sort(Comparator.comparingLong(x -> x.start));
            if (point && isCachedPointLimit(perWindowLimit)) {
                long[] counts = loadSampledPointCache(file, needed, destination, perWindowLimit);
                System.out.printf(Locale.ROOT,
                        "%s姿态记录：缓存命中=%d，内存保留=%d，窗口=%d，读取=持久采样缓存，单窗口上限=%d%n",
                        "点", counts[0], counts[1], ranges.size(), perWindowLimit);
                return;
            }
            long selectedBytes = ranges.stream().mapToLong(x -> x.end - x.start).sum();
            // 小/中场景通常只命中姿态文件的一小部分。采用有限跨度的批量随机读取，
            // 既避免逐窗口seek，也避免为每个场景重复扫描整张4.6GB点姿态表。
            boolean sequential = ranges.size() > 20_000 || selectedBytes > Files.size(file) * 3 / 4;
            long[] counts = sequential
                    ? loadAttitudesSequential(file, point, perWindowLimit, ranges, destination)
                    : loadAttitudesRandom(file, point, perWindowLimit, ranges, destination);
            System.out.printf(Locale.ROOT,
                    "%s姿态记录：源命中=%d，内存保留=%d，窗口=%d，读取=%s，选中字节比例=%.3f，单窗口上限=%s%n",
                    point ? "点" : "区域", counts[0], counts[1], ranges.size(),
                    sequential ? "顺序" : "索引", Files.size(file) == 0 ? 0.0 : (double) selectedBytes / Files.size(file),
                    perWindowLimit == Integer.MAX_VALUE ? "全部" : Integer.toString(perWindowLimit));
        }

        private long[] loadSampledPointCache(Path source, Set<String> needed,
                                              Map<String, List<Attitude>> destination,
                                              int limit) throws IOException {
            Path cacheDir = data.resolve(".xzlj-cache");
            Files.createDirectories(cacheDir);
            int cacheLimit = limit;
            String stem = source.getFileName().toString() + ".sampled-" + cacheLimit;
            Path index = cacheDir.resolve(stem + ".idx");
            Path binary = cacheDir.resolve(stem + ".bin");
            String signature = "#" + Files.size(source) + "\t"
                    + Files.getLastModifiedTime(source).toMillis() + "\t" + cacheLimit;
            ensureSampledPointCache(source, index, binary, signature, cacheLimit);

            List<SampledWindow> locations = new ArrayList<>();
            try (BufferedReader reader = Files.newBufferedReader(index, StandardCharsets.UTF_8)) {
                String header = reader.readLine();
                if (!signature.equals(header)) throw new IOException("点姿态采样缓存签名失效: " + index);
                String line;
                while ((line = reader.readLine()) != null) {
                    int first = line.indexOf('\t');
                    int second = first < 0 ? -1 : line.indexOf('\t', first + 1);
                    if (first <= 0 || second <= first) continue;
                    String windowId = line.substring(0, first);
                    if (needed.contains(windowId)) {
                        locations.add(new SampledWindow(windowId,
                                Long.parseLong(line.substring(first + 1, second)),
                                Integer.parseInt(line.substring(second + 1))));
                    }
                }
            }
            long selectedRecords = locations.stream().mapToLong(SampledWindow::count).sum();
            if (locations.size() > 20_000
                    || (double) selectedRecords * 112L > Files.size(binary) * 0.35) {
                return loadSampledPointCacheSequential(index, binary, signature, needed, destination, limit);
            }
            long matched = 0;
            long kept = 0;
            try (RandomAccessFile reader = new RandomAccessFile(binary.toFile(), "r")) {
                for (SampledWindow window : locations) {
                    if (reader.getFilePointer() != window.offset) reader.seek(window.offset);
                    List<Attitude> rows = new ArrayList<>(window.count);
                    for (int i = 0; i < window.count; i++) {
                        long start = reader.readLong();
                        long end = reader.readLong();
                        double roll = reader.readDouble();
                        double pitch = reader.readDouble();
                        double yaw = reader.readDouble();
                        double solar = reader.readDouble();
                        List<Point> strip = new ArrayList<>(4);
                        for (int p = 0; p < 4; p++) strip.add(new Point(reader.readDouble(), reader.readDouble()));
                        rows.add(new Attitude(window.windowId, start, end, roll, pitch, yaw, solar, strip));
                    }
                    matched += rows.size();
                    List<Attitude> selected = diversifyAttitudes(rows, limit);
                    kept += selected.size();
                    destination.put(window.windowId, selected);
                }
            }
            return new long[]{matched, kept};
        }

        private long[] loadSampledPointCacheSequential(Path index, Path binary, String signature,
                                                       Set<String> needed,
                                                       Map<String, List<Attitude>> destination,
                                                       int limit) throws IOException {
            long matched = 0;
            long kept = 0;
            long offset = 0;
            try (BufferedReader indexReader = Files.newBufferedReader(index, StandardCharsets.UTF_8);
                 DataInputStream binaryReader = new DataInputStream(new BufferedInputStream(
                         Files.newInputStream(binary), 8 * 1024 * 1024))) {
                if (!signature.equals(indexReader.readLine())) {
                    throw new IOException("点姿态采样缓存签名失效: " + index);
                }
                String line;
                while ((line = indexReader.readLine()) != null) {
                    int first = line.indexOf('\t');
                    int second = first < 0 ? -1 : line.indexOf('\t', first + 1);
                    if (first <= 0 || second <= first) continue;
                    String windowId = line.substring(0, first);
                    long indexedOffset = Long.parseLong(line.substring(first + 1, second));
                    int count = Integer.parseInt(line.substring(second + 1));
                    if (indexedOffset != offset || count < 0 || count > limit) {
                        throw new IOException("点姿态缓存索引内容无效: " + index);
                    }
                    if (needed.contains(windowId)) {
                        List<Attitude> rows = new ArrayList<>(count);
                        for (int i = 0; i < count; i++) rows.add(readCachedAttitude(binaryReader, windowId));
                        matched += rows.size();
                        List<Attitude> selected = diversifyAttitudes(rows, limit);
                        kept += selected.size();
                        destination.put(windowId, selected);
                    } else {
                        binaryReader.skipNBytes(count * 112L);
                    }
                    offset += count * 112L;
                }
            }
            if (Files.size(binary) != offset) throw new IOException("点姿态缓存长度与索引不一致: " + binary);
            return new long[]{matched, kept};
        }

        private static Attitude readCachedAttitude(DataInputStream reader, String windowId) throws IOException {
            long start = reader.readLong();
            long end = reader.readLong();
            double roll = reader.readDouble();
            double pitch = reader.readDouble();
            double yaw = reader.readDouble();
            double solar = reader.readDouble();
            List<Point> strip = new ArrayList<>(4);
            for (int i = 0; i < 4; i++) strip.add(new Point(reader.readDouble(), reader.readDouble()));
            return new Attitude(windowId, start, end, roll, pitch, yaw, solar, strip);
        }

        private static boolean isCachedPointLimit(int limit) {
            return limit == 8 || limit == 12 || limit == 32;
        }

        private void ensureSampledPointCache(Path source, Path index, Path binary,
                                              String signature, int limit) throws IOException {
            boolean valid = Files.isRegularFile(index) && Files.isRegularFile(binary);
            if (valid) {
                try (BufferedReader reader = Files.newBufferedReader(index, StandardCharsets.UTF_8)) {
                    valid = signature.equals(reader.readLine());
                }
            }
            if (valid) return;

            Path lock = index.resolveSibling(index.getFileName() + ".lock");
            boolean owner = false;
            try {
                try {
                    Files.createFile(lock);
                    owner = true;
                } catch (java.nio.file.FileAlreadyExistsException waiting) {
                    for (int i = 0; i < 600 && !Files.isRegularFile(index); i++) {
                        try {
                            Thread.sleep(100L);
                        } catch (InterruptedException interrupted) {
                            Thread.currentThread().interrupt();
                            throw new IOException("等待点姿态缓存时被中断", interrupted);
                        }
                    }
                    if (Files.isRegularFile(index)) return;
                    throw new IOException("等待点姿态采样缓存超时: " + index);
                }
                if (owner) buildSampledPointCache(source, index, binary, signature, limit);
            } finally {
                if (owner) Files.deleteIfExists(lock);
            }
        }

        private void buildSampledPointCache(Path source, Path index, Path binary,
                                             String signature, int limit) throws IOException {
            buildSampledPointCaches(source, List.of(new SampledCacheSpec(index, binary, signature, limit)));
        }

        private void ensureSampledPointCaches(Path source, int... limits) throws IOException {
            List<SampledCacheSpec> requested = new ArrayList<>();
            for (int limit : limits) {
                String stem = source.getFileName().toString() + ".sampled-" + limit;
                Path index = data.resolve(".xzlj-cache").resolve(stem + ".idx");
                Path binary = data.resolve(".xzlj-cache").resolve(stem + ".bin");
                String signature = "#" + Files.size(source) + "\t"
                        + Files.getLastModifiedTime(source).toMillis() + "\t" + limit;
                requested.add(new SampledCacheSpec(index, binary, signature, limit));
            }
            if (requested.stream().allMatch(this::isSampledCacheValid)) return;

            Path lock = data.resolve(".xzlj-cache")
                    .resolve(source.getFileName().toString() + ".sampled-all.lock");
            boolean owner = false;
            try {
                try {
                    Files.createFile(lock);
                    owner = true;
                } catch (java.nio.file.FileAlreadyExistsException waiting) {
                    for (int i = 0; i < 3_600; i++) {
                        if (requested.stream().allMatch(this::isSampledCacheValid)) return;
                        try {
                            Thread.sleep(100L);
                        } catch (InterruptedException interrupted) {
                            Thread.currentThread().interrupt();
                            throw new IOException("等待点姿态批量缓存时被中断", interrupted);
                        }
                    }
                    throw new IOException("等待点姿态批量缓存超时: " + lock);
                }
                if (owner) {
                    List<SampledCacheSpec> missing = requested.stream()
                            .filter(spec -> !isSampledCacheValid(spec)).toList();
                    if (!missing.isEmpty()) buildSampledPointCaches(source, missing);
                }
            } finally {
                if (owner) Files.deleteIfExists(lock);
            }
        }

        private boolean isSampledCacheValid(SampledCacheSpec spec) {
            if (!Files.isRegularFile(spec.index) || !Files.isRegularFile(spec.binary)) return false;
            try (BufferedReader reader = Files.newBufferedReader(spec.index, StandardCharsets.UTF_8)) {
                return spec.signature.equals(reader.readLine());
            } catch (IOException ignored) {
                return false;
            }
        }

        private void buildSampledPointCaches(Path source, List<SampledCacheSpec> specs) throws IOException {
            List<SampledCacheWriter> writers = new ArrayList<>();
            System.out.printf(Locale.ROOT, "首次准备点姿态缓存（每窗口%s条）：%s%n",
                    specs.stream().map(spec -> Integer.toString(spec.limit)).toList(), source.toAbsolutePath());
            try {
                for (SampledCacheSpec spec : specs) writers.add(new SampledCacheWriter(spec));
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                        new BufferedInputStream(Files.newInputStream(source), 8 * 1024 * 1024),
                        StandardCharsets.UTF_8), 1024 * 1024)) {
                    reader.readLine();
                    String current = null;
                    List<Attitude> rows = new ArrayList<>();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        int comma = line.indexOf(',');
                        if (comma <= 0) continue;
                        String windowId = line.substring(0, comma);
                        if (current != null && !current.equals(windowId)) {
                            for (SampledCacheWriter writer : writers) writer.writeWindow(current, rows);
                            rows = new ArrayList<>();
                        }
                        current = windowId;
                        Attitude attitude = parseAttitude(line, windowId, true);
                        if (attitude != null) rows.add(attitude);
                    }
                    if (current != null) {
                        for (SampledCacheWriter writer : writers) writer.writeWindow(current, rows);
                    }
                }
            } finally {
                IOException closeFailure = null;
                for (SampledCacheWriter writer : writers) {
                    try {
                        writer.close();
                    } catch (IOException failure) {
                        if (closeFailure == null) closeFailure = failure;
                        else closeFailure.addSuppressed(failure);
                    }
                }
                if (closeFailure != null) throw closeFailure;
            }
            for (SampledCacheWriter writer : writers) writer.commit();
            System.out.println("点姿态采样缓存已建立：" + writers.stream()
                    .map(writer -> writer.binary.toString()).toList());
        }

        private record SampledWindow(String windowId, long offset, int count) { }

        private record SampledCacheSpec(Path index, Path binary, String signature, int limit) { }

        private static final class SampledCacheWriter implements AutoCloseable {
            final Path index;
            final Path binary;
            final Path indexTmp;
            final Path binaryTmp;
            final int limit;
            final BufferedWriter indexWriter;
            final DataOutputStream binaryWriter;
            long offset;
            boolean closed;

            SampledCacheWriter(SampledCacheSpec spec) throws IOException {
                index = spec.index;
                binary = spec.binary;
                limit = spec.limit;
                indexTmp = index.resolveSibling(index.getFileName() + ".tmp");
                binaryTmp = binary.resolveSibling(binary.getFileName() + ".tmp");
                indexWriter = Files.newBufferedWriter(indexTmp, StandardCharsets.UTF_8);
                binaryWriter = new DataOutputStream(new BufferedOutputStream(
                        Files.newOutputStream(binaryTmp), 8 * 1024 * 1024));
                indexWriter.write(spec.signature);
                indexWriter.newLine();
            }

            void writeWindow(String windowId, List<Attitude> rows) throws IOException {
                offset = writeSampledRows(indexWriter, binaryWriter, windowId, rows, offset, limit);
            }

            void commit() throws IOException {
                Files.move(binaryTmp, binary, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                Files.move(indexTmp, index, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            }

            @Override
            public void close() throws IOException {
                if (closed) return;
                closed = true;
                IOException failure = null;
                try {
                    indexWriter.close();
                } catch (IOException closeFailure) {
                    failure = closeFailure;
                }
                try {
                    binaryWriter.close();
                } catch (IOException closeFailure) {
                    if (failure == null) failure = closeFailure;
                    else failure.addSuppressed(closeFailure);
                }
                if (failure != null) throw failure;
            }
        }

        private static long writeSampledRows(BufferedWriter indexWriter, DataOutputStream binaryWriter,
                                             String windowId, List<Attitude> rows, long offset,
                                             int limit) throws IOException {
            List<Attitude> selected = diversifyAttitudes(rows, limit);
            indexWriter.write(windowId + "\t" + offset + "\t" + selected.size());
            indexWriter.newLine();
            for (Attitude attitude : selected) {
                binaryWriter.writeLong(attitude.start);
                binaryWriter.writeLong(attitude.end);
                binaryWriter.writeDouble(attitude.roll);
                binaryWriter.writeDouble(attitude.pitch);
                binaryWriter.writeDouble(attitude.yaw);
                binaryWriter.writeDouble(attitude.solar);
                for (int i = 0; i < 4; i++) {
                    Point point = attitude.strip.size() > i ? attitude.strip.get(i) : new Point(0, 0);
                    binaryWriter.writeDouble(point.x);
                    binaryWriter.writeDouble(point.y);
                }
            }
            return offset + selected.size() * 112L;
        }

        static void preparePointAttitudeCache(Path dataDir, int limit) throws IOException {
            if (limit != 32) throw new IllegalArgumentException("当前缓存生成器只支持32条姿态");
            Repository repository = new Repository(dataDir);
            Path source = dataDir.resolve("vtw/points_vtws_attitudes.csv");
            Path cacheDir = dataDir.resolve(".xzlj-cache");
            Files.createDirectories(cacheDir);
            repository.ensureSampledPointCaches(source, 8, 12, 32);
        }

        private long[] loadAttitudesRandom(Path file, boolean point, int limit,
                                           List<AttitudeRange> ranges,
                                           Map<String, List<Attitude>> destination) throws IOException {
            final long mergeGap = 8L * 1024L;
            long matched = 0;
            long kept = 0;
            try (RandomAccessFile reader = new RandomAccessFile(file.toFile(), "r")) {
                int index = 0;
                while (index < ranges.size()) {
                    int endIndex = index + 1;
                    long groupEnd = ranges.get(index).end;
                    while (endIndex < ranges.size()
                            && ranges.get(endIndex).start - groupEnd <= mergeGap) {
                        groupEnd = ranges.get(endIndex).end;
                        endIndex++;
                    }
                    Map<String, List<Attitude>> grouped = new HashMap<>();
                    Set<String> ids = new HashSet<>();
                    for (int i = index; i < endIndex; i++) ids.add(ranges.get(i).windowId);
                    reader.seek(ranges.get(index).start);
                    while (reader.getFilePointer() < groupEnd) {
                        String line = reader.readLine();
                        if (line == null) break;
                        int comma = line.indexOf(',');
                        if (comma <= 0) continue;
                        String windowId = line.substring(0, comma);
                        if (!ids.contains(windowId)) continue;
                        Attitude attitude = parseAttitude(line, windowId, point);
                        if (attitude != null) grouped.computeIfAbsent(windowId, k -> new ArrayList<>()).add(attitude);
                    }
                    for (int i = index; i < endIndex; i++) {
                        AttitudeRange range = ranges.get(i);
                        List<Attitude> rows = grouped.getOrDefault(range.windowId, List.of());
                        matched += rows.size();
                        List<Attitude> selected = diversifyAttitudes(rows, limit);
                        if (!selected.isEmpty()) destination.put(range.windowId, selected);
                        kept += selected.size();
                    }
                    index = endIndex;
                }
            }
            return new long[]{matched, kept};
        }

        private long[] loadAttitudesSequential(Path file, boolean point, int limit,
                                               List<AttitudeRange> ranges,
                                               Map<String, List<Attitude>> destination) throws IOException {
            Map<String, String> canonical = new HashMap<>((int) Math.min(1_000_000L,
                    Math.max(16L, ranges.size() * 4L / 3L)));
            for (AttitudeRange range : ranges) canonical.put(range.windowId, range.windowId);
            long matched = 0;
            long kept = 0;
            String current = null;
            List<Attitude> rows = new ArrayList<>();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                    new BufferedInputStream(Files.newInputStream(file), 8 * 1024 * 1024),
                    StandardCharsets.UTF_8), 1024 * 1024)) {
                reader.readLine();
                String line;
                while ((line = reader.readLine()) != null) {
                    int comma = line.indexOf(',');
                    if (comma <= 0) continue;
                    String windowId = canonical.get(line.substring(0, comma));
                    if (windowId == null) continue;
                    if (current != null && !current.equals(windowId)) {
                        matched += rows.size();
                        List<Attitude> selected = diversifyAttitudes(rows, limit);
                        destination.put(current, selected);
                        kept += selected.size();
                        rows = new ArrayList<>();
                    }
                    current = windowId;
                    Attitude attitude = parseAttitude(line, windowId, point);
                    if (attitude != null) rows.add(attitude);
                }
            }
            if (current != null) {
                matched += rows.size();
                List<Attitude> selected = diversifyAttitudes(rows, limit);
                destination.put(current, selected);
                kept += selected.size();
            }
            return new long[]{matched, kept};
        }

        private static Attitude parseAttitude(String line, String windowId, boolean point) {
            List<String> c = splitCsv(line);
            if (c.isEmpty() || !windowId.equals(c.get(0))) return null;
            try {
                long first = utc(c.get(1));
                long start = point ? first - 5 : first;
                long end = point ? first + 5 : utc(c.get(2));
                return new Attitude(windowId, start, end,
                        dbl(c, point ? 2 : 3), dbl(c, point ? 3 : 4),
                        dbl(c, point ? 4 : 5), dbl(c, point ? 5 : 6),
                        parseStrip(c, point ? 6 : 7));
            } catch (RuntimeException ignored) {
                return null;
            }
        }

        private List<AttitudeRange> loadNeededRanges(Path source, Set<String> needed) throws IOException {
            Path cacheDir = data.resolve(".xzlj-cache");
            Files.createDirectories(cacheDir);
            Path index = cacheDir.resolve(source.getFileName().toString() + ".window-index.tsv");
            String signature = "#" + Files.size(source) + "\t" + Files.getLastModifiedTime(source).toMillis();
            boolean valid = false;
            if (Files.isRegularFile(index)) {
                try (BufferedReader reader = Files.newBufferedReader(index, StandardCharsets.UTF_8)) {
                    valid = signature.equals(reader.readLine());
                }
            }
            if (!valid) buildAttitudeIndex(source, index, signature);

            List<AttitudeRange> ranges = new ArrayList<>();
            try (BufferedReader reader = Files.newBufferedReader(index, StandardCharsets.UTF_8)) {
                reader.readLine();
                String line;
                while ((line = reader.readLine()) != null) {
                    int first = line.indexOf('\t');
                    int second = first < 0 ? -1 : line.indexOf('\t', first + 1);
                    if (first <= 0 || second <= first) continue;
                    String windowId = line.substring(0, first);
                    if (!needed.contains(windowId)) continue;
                    ranges.add(new AttitudeRange(windowId,
                            Long.parseLong(line.substring(first + 1, second)),
                            Long.parseLong(line.substring(second + 1))));
                }
            }
            return ranges;
        }

        private void buildAttitudeIndex(Path source, Path index, String signature) throws IOException {
            Path temporary = index.resolveSibling(index.getFileName().toString() + ".tmp");
            System.out.println("首次建立姿态窗口索引：" + source.toAbsolutePath());
            try (InputStream reader = new BufferedInputStream(Files.newInputStream(source), 8 * 1024 * 1024);
                 BufferedWriter writer = Files.newBufferedWriter(temporary, StandardCharsets.UTF_8)) {
                writer.write(signature);
                writer.newLine();
                long offset = 0;
                long lineStart = 0;
                boolean header = true;
                boolean firstColumn = true;
                StringBuilder window = new StringBuilder(48);
                String current = null;
                long rangeStart = 0;
                int value;
                while ((value = reader.read()) >= 0) {
                    offset++;
                    if (header) {
                        if (value == '\n') {
                            header = false;
                            lineStart = offset;
                        }
                        continue;
                    }
                    if (firstColumn && value == ',') {
                        firstColumn = false;
                    } else if (value == '\n') {
                        String windowId = window.toString();
                        if (!windowId.isEmpty()) {
                            if (current == null) {
                                current = windowId;
                                rangeStart = lineStart;
                            } else if (!current.equals(windowId)) {
                                writer.write(current + "\t" + rangeStart + "\t" + lineStart);
                                writer.newLine();
                                current = windowId;
                                rangeStart = lineStart;
                            }
                        }
                        window.setLength(0);
                        firstColumn = true;
                        lineStart = offset;
                    } else if (firstColumn && value != '\r') {
                        window.append((char) value);
                    }
                }
                if (current != null) {
                    writer.write(current + "\t" + rangeStart + "\t" + offset);
                    writer.newLine();
                }
            }
            Files.move(temporary, index, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            System.out.println("姿态窗口索引已建立：" + index.toAbsolutePath());
        }

        private static List<Attitude> diversifyAttitudes(List<Attitude> rows, int limit) {
            if (rows.size() <= limit) return rows;
            LinkedHashSet<Attitude> selected = new LinkedHashSet<>();
            for (int i = 0; i < limit; i++) {
                int index = limit == 1 ? rows.size() / 2
                        : (int) Math.round(i * (rows.size() - 1.0) / (limit - 1.0));
                selected.add(rows.get(index));
            }
            return new ArrayList<>(selected);
        }

        void retainOnlyCandidateAttitudes(Iterable<List<Observation>> selectedCandidates) {
            pointAttitudes.clear();
            areaAttitudes.clear();
            for (List<Observation> observations : selectedCandidates) {
                for (Observation observation : observations) {
                    Map<String, List<Attitude>> destination = observation.type == TaskType.POINT
                            ? pointAttitudes : areaAttitudes;
                    destination.computeIfAbsent(observation.windowId, k -> new ArrayList<>())
                            .add(observation);
                }
            }
        }
        private void loadAreaTargets(Path file, Set<String> needed) throws IOException { try(BufferedReader r=Files.newBufferedReader(file,StandardCharsets.UTF_8)){r.readLine();String line;while((line=r.readLine())!=null){List<String> c=splitCsv(line);if(c.size()>=6&&needed.contains(c.get(0)))areaTargets.put(c.get(0),new Polygon(parsePairs(c.get(5))));}}}
        private void loadPointTargets(Path file, Set<String> needed) throws IOException { try(BufferedReader r=Files.newBufferedReader(file,StandardCharsets.UTF_8)){r.readLine();String line;while((line=r.readLine())!=null){List<String> c=splitCsv(line);if(c.size()>=4&&needed.contains(c.get(0)))pointTargets.put(c.get(0),new Point(dbl(c,3),dbl(c,2)));}}}
        private void readTasks(Path file,List<Task> out,TaskType type)throws IOException{try(BufferedReader r=Files.newBufferedReader(file,StandardCharsets.UTF_8)){r.readLine();String line;while((line=r.readLine())!=null){List<String> c=splitCsv(line);if(c.size()<6)continue;Task t=new Task();t.id=c.get(0);t.targetId=c.get(1);t.score=Double.parseDouble(c.get(2));t.resolution=Double.parseDouble(c.get(3));t.windowStart=hm(c.get(4));t.windowEnd=hm(c.get(5));t.type=type;out.add(t);}}}
        private static String key(String a,String b){return a+"|"+b;}
        private static final class AttitudeRange {
            final String windowId;
            final long start;
            final long end;
            AttitudeRange(String windowId, long start, long end) {
                this.windowId = windowId;
                this.start = start;
                this.end = end;
            }
        }
    }

    static final class GreedySolver {
        final Repository repo; final Scenario scenario; int pointWithCandidates,areaWithCandidates;
        GreedySolver(Repository r,Scenario s){repo=r;scenario=s;}
        Schedule solve(){
            Schedule out=new Schedule();for(String id:scenario.resources)out.satStates.put(id,new SatelliteState());List<Task> tasks=new ArrayList<>();tasks.addAll(scenario.areaTasks);tasks.addAll(scenario.pointTasks);tasks.sort((a,b)->Double.compare(priority(b),priority(a)));
            for(Task task:tasks){List<Observation> cs=candidates(task);if(cs.isEmpty())continue;if(task.type==TaskType.POINT)pointWithCandidates++;else areaWithCandidates++;cs.sort((a,b)->Double.compare(candidateValue(b,task),candidateValue(a,task)));for(Observation o:cs){Satellite sat=repo.satellites.get(o.satelliteId);SatelliteState ss=out.satStates.get(o.satelliteId);if(!fitsObservation(o,sat,ss))continue;Transmission tx=selectTransmission(o,out,ss);if(tx==null)continue;ss.observations.add(o);ss.observations.sort(Comparator.comparingLong(x->x.start));ss.orbitLoad[orbit(o.start)]+=o.duration();ss.transmissions.add(tx);ss.transmissions.sort(Comparator.comparingLong(x->x.start));out.observations.add(o);out.transmissions.add(tx);out.completedTaskIds.add(task.id);out.estimatedScore+=task.type==TaskType.AREA?task.score*areaCoverage(task,o):task.score;break;}}
            List<Integer> order=new ArrayList<>();for(int i=0;i<out.observations.size();i++)order.add(i);order.sort(Comparator.comparingLong(i->out.observations.get(i).start));Schedule sorted=new Schedule();sorted.satStates=out.satStates;sorted.completedTaskIds=out.completedTaskIds;sorted.estimatedScore=out.estimatedScore;for(int i:order){sorted.observations.add(out.observations.get(i));sorted.transmissions.add(out.transmissions.get(i));}return sorted;
        }
        private double priority(Task t){return t.score*1000.0/Math.max(1,candidates(t).size())+(t.type==TaskType.AREA?0.5:0);}
        private double candidateValue(Observation o,Task t){return t.score*(t.type==TaskType.AREA?areaCoverage(t,o):1.0)/Math.max(1,o.duration());}
        List<Observation> candidates(Task task){
            List<Observation> out=new ArrayList<>();for(String satId:scenario.resources){Satellite sat=repo.satellites.get(satId);if(sat==null||sat.resolution>task.resolution)continue;String k=Repository.key(satId,task.targetId);
                if(task.type==TaskType.POINT){for(PointWindow w:repo.pointWindows.getOrDefault(k,List.of())){if(!overlap(w.start,w.end,task.windowStart,task.windowEnd))continue;for(Attitude a:repo.pointAttitudes.getOrDefault(w.windowId,List.of())){if(a.start<w.start-5||a.end>w.end+5)continue;if(validBase(a,sat,task)){Observation o=new Observation(task.id,task.targetId,satId,a.start,a.end,a.roll,a.pitch,a.yaw,a.solar,a.strip,task.type);o.windowId=a.windowId;out.add(o);}}}}
                else{for(AreaWindow w:repo.areaWindows.getOrDefault(k,List.of())){if(!overlap(w.start,w.end,task.windowStart,task.windowEnd))continue;for(Attitude a:repo.areaAttitudes.getOrDefault(w.windowId,List.of())){if(a.start<w.start||a.end>w.end)continue;if(validBase(a,sat,task)){Observation o=new Observation(task.id,task.targetId,satId,a.start,a.end,a.roll,a.pitch,a.yaw,a.solar,a.strip,task.type);o.windowId=a.windowId;o.targetPolygon=repo.areaTargets.get(task.targetId);out.add(o);}}}}
            }Map<String,Observation> unique=new LinkedHashMap<>();for(Observation o:out)unique.putIfAbsent(o.satelliteId+"|"+o.start+"|"+o.end+"|"+o.roll+"|"+o.pitch,o);return new ArrayList<>(unique.values());
        }
        private boolean validBase(Attitude a,Satellite sat,Task task){return a.start>=task.windowStart&&a.end<=task.windowEnd&&a.duration()>=sat.minWork&&anglesOk(a,sat);}
        boolean fitsObservation(Observation o,Satellite sat,SatelliteState ss){
            if(sat==null||o.duration()<sat.minWork||orbit(o.start)<0||orbit(o.start)>=ss.orbitLoad.length)return false;if(ss.orbitLoad[orbit(o.start)]+o.duration()>sat.maxOrbitWork)return false;
            Observation prev=null,next=null;for(Observation e:ss.observations){if(e.end<=o.start){if(prev==null||e.end>prev.end)prev=e;}else if(e.start>=o.end){if(next==null||e.start<next.start)next=e;}else return false;}return (prev==null||slewOk(prev,o,sat))&&(next==null||slewOk(o,next,sat));
        }
        Transmission selectTransmission(Observation o,Schedule state,SatelliteState ss){
            long need=Math.max(1,2L*o.duration());for(Arc arc:repo.arcsBySatellite.getOrDefault(o.satelliteId,List.of())){long from=Math.max(o.start,arc.start),to=arc.end;if(to-from<need)continue;long cursor=from;List<Interval> blocked=new ArrayList<>();for(Transmission x:ss.transmissions)blocked.add(block(x.start,x.end,!x.station.equals(arc.station)));for(Transmission x:state.transmissions)if(x.station.equals(arc.station)&&!x.satelliteId.equals(o.satelliteId))blocked.add(block(x.start,x.end,true));blocked.sort(Comparator.comparingLong(x->x.start));for(Interval b:blocked){if(cursor+need<=Math.min(b.start,to))return new Transmission(o.satelliteId,o.taskId,arc.station,cursor,cursor+need);cursor=Math.max(cursor,b.end);if(cursor>=to)break;}if(cursor+need<=to)return new Transmission(o.satelliteId,o.taskId,arc.station,cursor,cursor+need);}return null;
        }
        private Interval block(long s,long e,boolean gap){return new Interval(gap?s-TX_SWITCH_GAP:s,gap?e+TX_SWITCH_GAP:e);}
    }

    static ValidationReport validate(Schedule schedule,Repository repo,Scenario scenario){
        ValidationReport r=new ValidationReport();Set<String> seenPointTasks=new HashSet<>();
        for(int i=0;i<schedule.observations.size();i++){
            Observation o=schedule.observations.get(i);Transmission t=i<schedule.transmissions.size()?schedule.transmissions.get(i):null;Task task=scenario.taskById.get(o.taskId);Satellite sat=repo.satellites.get(o.satelliteId);
            if(!scenario.resources.contains(o.satelliteId))r.c1++;
            if(task!=null&&task.type==TaskType.POINT&&!seenPointTasks.add(task.id))r.c2++;
            if(task!=null&&sat!=null&&sat.resolution>task.resolution)r.c3++;
            if(task!=null&&(o.start<task.windowStart||o.end>task.windowEnd))r.c4++;
            if(task==null||!visibleFromProvidedData(o,task,repo))r.c5++;
            if(sat==null||o.roll<sat.rollMin||o.roll>sat.rollMax||o.pitch<sat.pitchMin||o.pitch>sat.pitchMax||Math.abs(o.yaw)>1e-9)r.c6++;
            if(sat!=null&&offNadir(o.roll,o.pitch)>sat.maxOffNadir+1e-9)r.c7++;
            if(sat!=null&&sat.type.equals("opt")&&o.solar<sat.solarReq)r.c8++;
            if(sat!=null&&sat.type.equals("sar")&&Math.abs(o.roll)+1e-9<sat.minAbsRoll)r.c9++;
            if(sat==null||o.duration()<sat.minWork)r.c10++;
            if(!insideArc(t,repo.arcsBySatellite.getOrDefault(o.satelliteId,List.of())))r.c12++;
            if(t==null||!o.satelliteId.equals(t.satelliteId)||!o.taskId.equals(t.taskId)||t.start<o.start||t.end-t.start<2L*o.duration())r.c14++;
        }
        for(SatelliteState ss:schedule.satStates.values()){
            List<Observation> os=new ArrayList<>(ss.observations);os.sort(Comparator.comparingLong(x->x.start));
            for(int i=1;i<os.size();i++){Satellite sat=repo.satellites.get(os.get(i).satelliteId);if(sat==null||!slewOk(os.get(i-1),os.get(i),sat))r.c11++;}
            long[] load=new long[16];for(Observation o:os)load[orbit(o.start)]+=o.duration();for(int i=0;i<load.length;i++){Satellite sat=os.isEmpty()?null:repo.satellites.get(os.get(0).satelliteId);if(sat!=null&&load[i]>sat.maxOrbitWork)r.c15++;}
        }
        Map<String,List<Transmission>> byStation=new HashMap<>(),bySatellite=new HashMap<>();for(Transmission t:schedule.transmissions){byStation.computeIfAbsent(t.station,k->new ArrayList<>()).add(t);bySatellite.computeIfAbsent(t.satelliteId,k->new ArrayList<>()).add(t);}
        for(List<Transmission> xs:byStation.values()){xs.sort(Comparator.comparingLong(x->x.start));for(int i=1;i<xs.size();i++){Transmission a=xs.get(i-1),b=xs.get(i);long need=a.satelliteId.equals(b.satelliteId)?0:TX_SWITCH_GAP;if(b.start-a.end<need)r.c13++;}}
        for(List<Transmission> xs:bySatellite.values()){xs.sort(Comparator.comparingLong(x->x.start));for(int i=1;i<xs.size();i++){Transmission a=xs.get(i-1),b=xs.get(i);long need=a.station.equals(b.station)?0:TX_SWITCH_GAP;if(b.start-a.end<need)r.c13++;}}
        r.totalViolations=r.c1+r.c2+r.c3+r.c4+r.c5+r.c6+r.c7+r.c8+r.c9+r.c10+r.c11+r.c12+r.c13+r.c14+r.c15;return r;
    }
    private static boolean visibleFromProvidedData(Observation o,Task task,Repository repo){
        String k=Repository.key(o.satelliteId,task.targetId);boolean window=false;
        if(task.type==TaskType.POINT){for(PointWindow w:repo.pointWindows.getOrDefault(k,List.of()))if(w.windowId.equals(o.windowId)&&o.start>=w.start-5&&o.end<=w.end+5){window=true;break;}}
        else{for(AreaWindow w:repo.areaWindows.getOrDefault(k,List.of()))if(w.windowId.equals(o.windowId)&&o.start>=w.start&&o.end<=w.end){window=true;break;}}
        if(!window)return false;Map<String,List<Attitude>> source=task.type==TaskType.POINT?repo.pointAttitudes:repo.areaAttitudes;for(Attitude a:source.getOrDefault(o.windowId,List.of()))if(a.start==o.start&&a.end==o.end&&Math.abs(a.roll-o.roll)<1e-7&&Math.abs(a.pitch-o.pitch)<1e-7)return true;return false;
    }
    private static boolean insideArc(Transmission t,List<Arc> arcs){if(t==null)return false;for(Arc a:arcs)if(a.station.equals(t.station)&&t.start>=a.start&&t.end<=a.end)return true;return false;}
    private static boolean anglesOk(Attitude a,Satellite s){if(a.roll<s.rollMin||a.roll>s.rollMax||a.pitch<s.pitchMin||a.pitch>s.pitchMax)return false;if(offNadir(a.roll,a.pitch)>s.maxOffNadir+1e-9)return false;if(s.type.equals("opt")&&a.solar<s.solarReq)return false;return !s.type.equals("sar")||Math.abs(a.roll)+1e-9>=s.minAbsRoll;}
    private static double offNadir(double roll,double pitch){double r=Math.toRadians(roll),p=Math.toRadians(pitch);return Math.toDegrees(Math.acos(Math.max(-1,Math.min(1,Math.cos(r)*Math.cos(p)))));}
    private static boolean slewOk(Observation earlier,Observation later,Satellite sat){long gap=later.start-earlier.end;if(gap<0)return false;if(sat.type.equals("opt"))return gap>=(long)Math.ceil(slewAngle(earlier.roll,earlier.pitch,later.roll,later.pitch)/Math.max(1e-9,sat.slewSpeed));boolean same=(earlier.roll>=0&&later.roll>=0)||(earlier.roll<0&&later.roll<0);return gap>=(same?sat.sameSideSlew:sat.oppSideSlew);}
    private static double slewAngle(double r1,double p1,double r2,double p2){double a=Math.toRadians(r1),b=Math.toRadians(r2),c=Math.toRadians(p1-p2);double cos=Math.cos(a)*Math.cos(b)*Math.cos(c)+Math.sin(a)*Math.sin(b);return Math.toDegrees(Math.acos(Math.max(-1,Math.min(1,cos))));}
    private static boolean overlap(long a,long b,long c,long d){return a<=d&&c<=b;} private static int orbit(long sec){return(int)(sec/5400L);}
    static double areaCoverage(Task task,Observation o){if(o.strip==null||o.strip.size()<3||o.targetPolygon==null)return 0;return o.targetPolygon.intersectionRatio(o.strip);}
    private static List<Point> parseStrip(List<String> c,int first){if(c.size()<first+8)return List.of();List<Point> p=new ArrayList<>();p.add(new Point(dbl(c,first+1),dbl(c,first)));p.add(new Point(dbl(c,first+3),dbl(c,first+2)));p.add(new Point(dbl(c,first+7),dbl(c,first+6)));p.add(new Point(dbl(c,first+5),dbl(c,first+4)));return p;}
    private static List<Point> parsePairs(String raw){List<Point> p=new ArrayList<>();Matcher m=COORD_PAIR.matcher(raw);while(m.find())p.add(new Point(Double.parseDouble(m.group(1)),Double.parseDouble(m.group(2))));return p;}
    private static long utc(String value){String v=unquote(value.trim());if(v.matches("\\d+"))return Long.parseLong(v);return Instant.parse(v).getEpochSecond()-Instant.parse("2026-01-01T00:00:00Z").getEpochSecond();}
    private static long hm(String value){String v=unquote(value.trim());if(v.equals("24:00")||v.equals("24:00:00"))return 86400L;return LocalTime.parse(v.length()==5?v+":00":v).toSecondOfDay();}
    private static double dbl(List<String> c,int i){return Double.parseDouble(unquote(c.get(i)));} private static long lng(List<String> c,int i){return Math.round(dbl(c,i));}
    private static String unquote(String s){return s!=null&&s.length()>=2&&s.startsWith("\"")&&s.endsWith("\"")?s.substring(1,s.length()-1).replace("\"\"","\""):s;}
    private static List<String> splitCsv(String line){List<String> out=new ArrayList<>();StringBuilder b=new StringBuilder();boolean quoted=false;for(int i=0;i<line.length();i++){char ch=line.charAt(i);if(ch=='"'){if(quoted&&i+1<line.length()&&line.charAt(i+1)=='"'){b.append('"');i++;}else quoted=!quoted;}else if(ch==','&&!quoted){out.add(unquote(b.toString().trim()));b.setLength(0);}else b.append(ch);}out.add(unquote(b.toString().trim()));return out;}

    enum TaskType{POINT,AREA}
    static final class Scenario{final String name;final Set<String> resources=new LinkedHashSet<>();final List<Task> pointTasks=new ArrayList<>(),areaTasks=new ArrayList<>();final Map<String,Task> taskById=new HashMap<>();Scenario(String n){name=n;}Set<String> pointTargetIds(){Set<String>s=new HashSet<>();for(Task t:pointTasks)s.add(t.targetId);return s;}Set<String> areaTargetIds(){Set<String>s=new HashSet<>();for(Task t:areaTasks)s.add(t.targetId);return s;}}
    static final class Task{String id,targetId;double score,resolution;long windowStart,windowEnd;TaskType type;}
    static final class Satellite{String id,type;double rollMin,rollMax,pitchMin,pitchMax,maxOffNadir,minAbsRoll,solarReq,resolution,slewSpeed;long minWork,maxOrbitWork,sameSideSlew,oppSideSlew;}
    static final class Arc{String satelliteId,station;long start,end;Arc(String s,String st,long a,long b){satelliteId=s;station=st;start=a;end=b;}}
    static final class PointWindow{String windowId,satelliteId,targetId;long start,end;PointWindow(String w,String s,String t,long a,long b){windowId=w;satelliteId=s;targetId=t;start=a;end=b;}}
    static final class AreaWindow{String windowId,satelliteId,targetId;long start,end;AreaWindow(String w,String s,String t,long a,long b){windowId=w;satelliteId=s;targetId=t;start=a;end=b;}}
    static class Attitude{String windowId;long start,end;double roll,pitch,yaw,solar;List<Point> strip;Attitude(String w,long a,long b,double r,double p,double y,double so,List<Point> q){windowId=w;start=a;end=b;roll=r;pitch=p;yaw=y;solar=so;strip=q;}long duration(){return end-start;}}
    static final class Observation extends Attitude{String taskId,targetId,satelliteId;TaskType type;Polygon targetPolygon;Observation(String task,String target,String sat,long a,long b,double r,double p,double y,double so,List<Point>q,TaskType typ){super("",a,b,r,p,0.0,so,q);taskId=task;targetId=target;satelliteId=sat;type=typ;}}
    static final class Transmission{String satelliteId,taskId,station;long start,end;Transmission(String s,String t,String st,long a,long b){satelliteId=s;taskId=t;station=st;start=a;end=b;}}
    static final class SatelliteState{final List<Observation> observations=new ArrayList<>();final List<Transmission> transmissions=new ArrayList<>();final long[] orbitLoad=new long[16];}
    static final class Schedule{final List<Observation> observations=new ArrayList<>();final List<Transmission> transmissions=new ArrayList<>();Set<String> completedTaskIds=new HashSet<>();Map<String,SatelliteState> satStates=new HashMap<>();double estimatedScore;}
    static final class Interval{long start,end;Interval(long a,long b){start=a;end=b;}}
    static final class Point{double x,y;Point(double a,double b){x=a;y=b;}}
    static final class Polygon{final List<Point>points;Polygon(List<Point>p){points=p;}double intersectionRatio(List<Point>other){if(points.size()<3||other.size()<3)return 0;Area a=new Area(path(points));a.intersect(new Area(path(other)));double total=Math.abs(signedArea(points));return total<1e-12?0:Math.max(0,Math.min(1,pathArea(a)/total));}double unionIntersectionRatio(List<List<Point>> strips){if(points.size()<3)return 0;Area union=new Area();for(List<Point>strip:strips)if(strip!=null&&strip.size()>=3)union.add(new Area(path(strip)));union.intersect(new Area(path(points)));double total=Math.abs(signedArea(points));return total<1e-12?0:Math.max(0,Math.min(1,pathArea(union)/total));}private static Path2D path(List<Point>p){Path2D x=new Path2D.Double();x.moveTo(p.get(0).x,p.get(0).y);for(int i=1;i<p.size();i++)x.lineTo(p.get(i).x,p.get(i).y);x.closePath();return x;}private static double signedArea(List<Point>p){double a=0;for(int i=0;i<p.size();i++){Point u=p.get(i),v=p.get((i+1)%p.size());a+=u.x*v.y-v.x*u.y;}return a/2;}private static double pathArea(Area a){PathIterator it=a.getPathIterator(null);double[]q=new double[6];double sum=0,sx=0,sy=0,px=0,py=0;while(!it.isDone()){int t=it.currentSegment(q);if(t==PathIterator.SEG_MOVETO){sx=px=q[0];sy=py=q[1];}else if(t==PathIterator.SEG_LINETO){sum+=px*q[1]-q[0]*py;px=q[0];py=q[1];}else if(t==PathIterator.SEG_CLOSE)sum+=px*sy-sx*py;it.next();}return Math.abs(sum/2);}}
    static final class ValidationReport{int c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,c11,c12,c13,c14,c15,totalViolations;String summary(){return"c1="+c1+", c2="+c2+", c3="+c3+", c4="+c4+", c5="+c5+", c6="+c6+", c7="+c7+", c8="+c8+", c9="+c9+", c10="+c10+", c11="+c11+", c12="+c12+", c13="+c13+", c14="+c14+", c15="+c15;}}
}

/**
 * 面向大规模场景的混合自适应大邻域搜索（ALNS）。
 *
 * 结构：覆盖感知贪心初解 + 自适应破坏/修复 + 模拟退火接受 + 区域多条带强化。
 * 全部候选均来自官方数据，所有插入均复用 GreedyAlgorithm 的约束和数传分配逻辑。
 *
 * 命令行参数：
 *   1. scenario       场景名，例如 10-300
 *   2. dataDir        data目录
 *   3. outputDir      输出目录
 *   4. seconds        按墙钟时间搜索的秒数
 *   5. seed           随机种子
 *   6. maxIterations  可选，固定迭代上限；0表示不启用
 */
final class ImprovedALNS {
    // 这是防止搜索无限追加冗余条带的工程上限，不是比赛规则中的区域条带数量限制。
    // 规则允许同一任务选择多个时间上不冲突的条带，因此保留更大的搜索空间。
    private static final int MAX_AREA_STRIPS = 20;
    // GRASP/全局边际和后处理局部搜索的高开销仅用于小场景；更大场景使用主ALNS。
    private static final int ENHANCED_INIT_TASK_LIMIT = 500;
    private static final int RCL_SIZE = 3;
    // chooseCandidate只需要最好的少量候选。原实现会为每个任务完整排序
    // 其全部候选；在ALNS反复重建时，这个排序成为主要CPU热点。
    private static final int CHOICE_POOL_SIZE = 12;
    private static final double EPS = 1e-8;

    // 破坏算子和修复算子的编号会在日志和注释中按这个顺序解释。
    private static final String[] DESTROY_NAMES = {
            "random", "marginal-loss", "uncovered-target", "shaw-related", "satellite-orbit"
    };
    private static final String[] REPAIR_NAMES = {
            "score", "scarcity", "coverage-potential", "regret-2"
    };

    private ImprovedALNS() {
    }

    public static void main(String[] args) throws Exception {
        if (args.length > 0 && (args[0].equals("-h") || args[0].equals("--help"))) {
            printUsage();
            return;
        }
        long programStart = System.nanoTime();
        String scenarioName = args.length > 0 && !args[0].isBlank() ? args[0] : "10-300";
        Path dataDir = args.length > 1 ? Paths.get(args[1]) : GreedyAlgorithm.findDataDir();
        Path outputDir = args.length > 2 ? Paths.get(args[2]) : dataDir.resolve("results");
        int seconds = args.length > 3 ? Integer.parseInt(args[3]) : 45;
        long seed = args.length > 4 ? Long.parseLong(args[4]) : 20260822L;
        int maxIterations = args.length > 5 ? Integer.parseInt(args[5]) : 0;
        if (seconds < 1 || maxIterations < 0) {
            throw new IllegalArgumentException("seconds必须 >= 1，maxIterations必须 >= 0");
        }
        Files.createDirectories(outputDir);

        System.out.println("=== 混合改进大邻域搜索（ALNS）===");
        System.out.println("data=" + dataDir.toAbsolutePath());
        System.out.printf(Locale.ROOT, "scenario=%s, search=%ds, seed=%d, maxIterations=%d%n",
                scenarioName, seconds, seed, maxIterations);

        GreedyAlgorithm.Repository repo = new GreedyAlgorithm.Repository(dataDir);
        long stage = System.nanoTime();
        repo.loadBase(scenarioName);
        System.out.printf(Locale.ROOT, "STAGE_TIME loadBase=%.3f%n", (System.nanoTime() - stage) / 1_000_000_000.0);
        stage = System.nanoTime();
        GreedyAlgorithm.Scenario scenario = repo.loadScenario(scenarioName);
        GreedyAlgorithm.GreedySolver feasibility = new GreedyAlgorithm.GreedySolver(repo, scenario);
        CoverageOracle oracle = new CoverageOracle(repo, scenario);
        CandidateCatalog catalog = new CandidateCatalog(feasibility, scenario, oracle);
        catalog.build();
        System.out.printf(Locale.ROOT, "STAGE_TIME catalog=%.3f%n", (System.nanoTime() - stage) / 1_000_000_000.0);

        stage = System.nanoTime();
        Solver solver = new Solver(repo, scenario, feasibility, oracle, catalog, seed);
        Solution best = solver.solve(seconds, maxIterations);
        System.out.printf(Locale.ROOT, "STAGE_TIME solve=%.3f%n", (System.nanoTime() - stage) / 1_000_000_000.0);
        GreedyAlgorithm.Schedule outputSchedule = sortPairs(best.schedule);
        GreedyAlgorithm.ValidationReport report = GreedyAlgorithm.validate(outputSchedule, repo, scenario);
        if (report.totalViolations != 0) {
            throw new IllegalStateException("拒绝输出存在约束违规的方案: " + report.summary());
        }

        // evaluator.jar从 data/results/<scenario>.csv 读取方案，文件名不能带-alns后缀。
        Path output = outputDir.resolve(scenarioName + ".csv");
        GreedyAlgorithm.writeSchedule(output, outputSchedule);
        double theoretical = scenario.taskById.values().stream().mapToDouble(t -> t.score).sum();
        System.out.printf(Locale.ROOT,
                "结果：观测=%d，数传=%d，点任务覆盖=%d/%d，区域任务有覆盖=%d/%d%n",
                outputSchedule.observations.size(), outputSchedule.transmissions.size(),
                best.pointCovered.size(), scenario.pointTasks.size(), best.areaRatios.size(), scenario.areaTasks.size());
        System.out.printf(Locale.ROOT,
                "内部覆盖估算收益=%.2f / %.2f (%.2f%%)，迭代=%d，改进=%d%n",
                best.score, theoretical, theoretical == 0 ? 0 : 100.0 * best.score / theoretical,
                solver.iterations, solver.improvements);
        System.out.println("15项约束检查：0违规（" + report.summary() + "）");
        System.out.println("已写出：" + output.toAbsolutePath());
        System.out.println("注意：内部覆盖收益用于搜索，不等同于官方 evaluator.jar 的最终得分。");
        double elapsedSeconds = (System.nanoTime() - programStart) / 1_000_000_000.0;
        System.out.printf(Locale.ROOT,
                "MACHINE_RESULT scenario=%s score=%.6f theoretical=%.6f candidateUpper=%.6f "
                        + "initialScore=%.6f pointCovered=%d pointTotal=%d areaCovered=%d areaTotal=%d "
                        + "observations=%d transmissions=%d violations=%d iterations=%d "
                        + "improvements=%d elapsedSeconds=%.3f%n",
                scenarioName, best.score, theoretical, catalog.optimisticUpper, solver.initialScore,
                best.pointCovered.size(), scenario.pointTasks.size(),
                best.areaRatios.size(), scenario.areaTasks.size(),
                outputSchedule.observations.size(), outputSchedule.transmissions.size(),
                report.totalViolations, solver.iterations, solver.improvements, elapsedSeconds);
        System.out.println("破坏算子使用次数：" + solver.operatorSummary(DESTROY_NAMES, true));
        System.out.println("修复算子使用次数：" + solver.operatorSummary(REPAIR_NAMES, false));
    }

    private static void printUsage() {
        System.out.println("用法：java ImprovedALNS [scenario] [dataDir] [outputDir] [seconds] [seed] [maxIterations]");
        System.out.println("示例：java -Xmx6g -cp bin ImprovedALNS 10-300 ..\\data output 5 20260822");
        System.out.println("固定迭代实验：java -Xmx6g -cp bin ImprovedALNS 10-300 ..\\data output 300 20260822 1000");
        System.out.println("maxIterations=0表示只按seconds停止；大于0时两者先到者停止。");
    }

    private static final class Solver {
        final GreedyAlgorithm.Repository repo;
        final GreedyAlgorithm.Scenario scenario;
        final GreedyAlgorithm.GreedySolver feasibility;
        final CoverageOracle oracle;
        final CandidateCatalog catalog;
        final Random random;
        final double[] destroyWeights = {2.0, 1.0, 4.0, 1.0, 1.0};
        final double[] repairWeights = {3.0, 3.0, 2.0, 0.5};
        final double[] destroyScores = new double[destroyWeights.length];
        final double[] repairScores = new double[repairWeights.length];
        final int[] destroyUses = new int[destroyWeights.length];
        final int[] repairUses = new int[repairWeights.length];
        // Uses用于当前50轮的权重更新；totalUses用于最终诊断，不能随窗口更新清零。
        final int[] totalDestroyUses = new int[destroyWeights.length];
        final int[] totalRepairUses = new int[repairWeights.length];
        int iterations;
        int improvements;
        double initialScore;
        int initialRestarts;
        int graspInitials;
        int pathRelinkingEvaluations;
        int taskPolishEvaluations;
        int largePerturbations;
        int deepRuinRecreates;
        int independentRestarts;
        int eliteMixes;
        final List<EliteEntry> eliteArchive = new ArrayList<>();

        Solver(GreedyAlgorithm.Repository repo, GreedyAlgorithm.Scenario scenario,
               GreedyAlgorithm.GreedySolver feasibility, CoverageOracle oracle,
               CandidateCatalog catalog, long seed) {
            this.repo = repo;
            this.scenario = scenario;
            this.feasibility = feasibility;
            this.oracle = oracle;
            this.catalog = catalog;
            this.random = new Random(seed);
        }

        Solution solve(int seconds, int maxIterations) {
            long solveStage = System.nanoTime();
            List<GreedyAlgorithm.Task> baseOrder = new ArrayList<>(scenario.taskById.values());
            baseOrder.sort(Comparator
                    .comparingDouble((GreedyAlgorithm.Task t) -> -catalog.taskPotential(t.id))
                    .thenComparingInt(t -> catalog.candidates(t.id).size()));

            List<List<GreedyAlgorithm.Task>> initialOrders = new ArrayList<>();
            initialOrders.add(baseOrder);
            List<GreedyAlgorithm.Task> byScore = new ArrayList<>(baseOrder);
            byScore.sort(Comparator.comparingDouble((GreedyAlgorithm.Task t) -> -t.score));
            initialOrders.add(byScore);
            List<GreedyAlgorithm.Task> byScarcity = new ArrayList<>(baseOrder);
            byScarcity.sort(Comparator.comparingDouble((GreedyAlgorithm.Task t) ->
                    -t.score / Math.max(1, catalog.rawCount(t.id))));
            initialOrders.add(byScarcity);

            Solution current = null;
            List<GreedyAlgorithm.Task> currentOrder = baseOrder;
            for (List<GreedyAlgorithm.Task> order : initialOrders) {
                Solution candidate = construct(order, false);
                if (current == null || candidate.score > current.score) {
                    current = candidate;
                    currentOrder = new ArrayList<>(order);
                }
            }
            // 多起点只用于小场景：不同的任务排列会触发不同的姿态/数传组合，
            // 可以直接检验“初始解质量是否限制后续搜索”，而不是把差异误归因于算子。
            if (scenario.taskById.size() <= ENHANCED_INIT_TASK_LIMIT) {
                int restarts = 4;
                for (int restart = 0; restart < restarts; restart++) {
                    List<GreedyAlgorithm.Task> randomizedOrder = new ArrayList<>(baseOrder);
                    Collections.shuffle(randomizedOrder, random);
                    Solution candidate = construct(randomizedOrder, true);
                    initialRestarts++;
                    if (candidate.score > current.score + EPS) {
                        current = candidate;
                        currentOrder = new ArrayList<>(randomizedOrder);
                    }
                }
                // 真正的GRASP初解：任务选择和候选选择都在当前部分调度上动态计算。
                // 这与“固定任务顺序后随机挑候选”不同，能产生结构上不同的初始解。
                // 8个互补GRASP模式用于保持既有初解质量；减少数量会导致固定预算下收益退化。
                for (int mode = 0; mode < 8; mode++) {
                    GraspResult grasp = constructGrasp(mode);
                    graspInitials++;
                    if (current == null || grasp.solution.score > current.score + EPS) {
                        current = grasp.solution;
                        currentOrder = grasp.order;
                    }
                }
                // 全局边际收益构造：不先锁定任务，再从所有候选中直接选择下一条观测。
                // 这专门利用“一条条带可以顺带覆盖多个点任务”的交叉覆盖结构。
                for (int mode = 0; mode < 4; mode++) {
                    GraspResult global = constructGlobalMarginal(mode);
                    graspInitials++;
                    if (current == null || global.solution.score > current.score + EPS) {
                        current = global.solution;
                        currentOrder = global.order;
                    }
                }
            }
            Solution best = current;
            initialScore = current.score;
            System.out.printf(Locale.ROOT, "STAGE_TIME initial=%.3f%n",
                    (System.nanoTime() - solveStage) / 1_000_000_000.0);
            rememberElite(current);
            if (scenario.taskById.size() <= ENHANCED_INIT_TASK_LIMIT) {
                Solution legacy = evaluate(feasibility.solve());
                System.out.printf(Locale.ROOT,
                        "原贪心同口径复核：收益=%.2f，点=%d，观测=%d%n",
                        legacy.score, legacy.pointCovered.size(), legacy.schedule.observations.size());
                if (legacy.score > best.score) best = legacy;
            }
            long deadline = System.nanoTime() + Math.max(1, seconds) * 1_000_000_000L;
            double temperature = Math.max(5.0, current.score * 0.012);
            int epoch = 0;

            System.out.printf(Locale.ROOT,
                    "覆盖感知初解：收益=%.2f，点=%d，观测=%d%n",
                    current.score, current.pointCovered.size(), current.schedule.observations.size());

            // 默认按时间停止；如果给了maxIterations，则取“时间上限”和“迭代上限”中先到者。
            while (System.nanoTime() < deadline
                    && (maxIterations <= 0 || iterations < maxIterations)) {
                iterations++;
                int destroy = roulette(destroyWeights);
                int repair = roulette(repairWeights);
                destroyUses[destroy]++;
                repairUses[repair]++;
                totalDestroyUses[destroy]++;
                totalRepairUses[repair]++;
                List<GreedyAlgorithm.Task> nextOrder;
                Solution next;
                // 普通ALNS之外，定期执行大扰动和独立重启，避免一直在初始解附近爬行。
                // 当前最优解best始终保留，探索状态current可以暂时变差。
                if (iterations % 50 == 0 && eliteArchive.size() >= 2) {
                    nextOrder = new ArrayList<>(currentOrder);
                    next = eliteRecombine();
                    eliteMixes++;
                    temperature = Math.max(temperature, Math.max(8.0, best.score * 0.012));
                } else if (iterations % 70 == 0) {
                    nextOrder = independentRestartOrder();
                    next = construct(nextOrder, true);
                    independentRestarts++;
                    temperature = Math.max(temperature, Math.max(6.0, best.score * 0.008));
                } else if (iterations % 35 == 0) {
                    nextOrder = largeOrderPerturbation(currentOrder);
                    next = deepDestroyRepair(current);
                    largePerturbations++;
                    deepRuinRecreates++;
                    temperature = Math.max(temperature, Math.max(8.0, best.score * 0.010));
                } else {
                    nextOrder = changeNeighborhood(currentOrder, current, destroy, repair);
                    // 两类普通大邻域交替：任务排列重建，以及直接对当前可行调度做成组移除/回填。
                    next = iterations % 2 == 0
                            ? destroyRepair(current, destroy, repair)
                            : construct(nextOrder, random.nextDouble() < 0.35);
                }
                double delta = next.score - current.score;
                double jumpAllowance = (iterations % 35 == 0 || iterations % 70 == 0)
                        ? Math.max(10.0, best.score * 0.025) : 0.0;
                boolean accepted = delta >= 0
                        || delta >= -jumpAllowance
                        || random.nextDouble() < Math.exp(delta / Math.max(0.05, temperature));
                if (accepted) {
                    current = next;
                    currentOrder = nextOrder;
                    rememberElite(current);
                }
                double reward = accepted ? 3.0 : 0.0;
                if (next.score > best.score + EPS) {
                    best = next;
                    rememberElite(best);
                    improvements++;
                    reward = 33.0;
                    System.out.printf(Locale.ROOT,
                            "[ALNS] iter=%d, best=%.2f, point=%d, obs=%d%n",
                            iterations, best.score, best.pointCovered.size(), best.schedule.observations.size());
                } else if (delta > EPS) {
                    reward = 9.0;
                }
                destroyScores[destroy] += reward;
                repairScores[repair] += reward;
                temperature *= 0.993;
                if (++epoch % 50 == 0) updateOperatorWeights();
                if (epoch % 80 == 0) temperature = Math.max(1.0, best.score * 0.004);
                if (epoch % 250 == 0) current = best;
            }
            long polishStage = System.nanoTime();
            // 小场景候选较完整，ALNS结束后再做有限的可行插入局部搜索。
            // 这一步只接受正收益插入，并复用同一套可行性和数传检查。
            if (scenario.taskById.size() <= ENHANCED_INIT_TASK_LIMIT) {
                double beforeRelinking = best.score;
                List<List<GreedyAlgorithm.Task>> relinkOrders = new ArrayList<>();
                relinkOrders.add(new ArrayList<>(baseOrder));
                relinkOrders.add(new ArrayList<>(byScore));
                relinkOrders.add(new ArrayList<>(byScarcity));
                relinkOrders.add(new ArrayList<>(currentOrder));
                for (int i = 0; i < relinkOrders.size(); i++) {
                    for (int j = i + 1; j < relinkOrders.size(); j++) {
                        Solution relinked = pathRelinking(relinkOrders.get(i), relinkOrders.get(j), best, 12);
                        if (relinked.score > best.score + EPS) best = relinked;
                    }
                }
                if (best.score > beforeRelinking + EPS) {
                    System.out.printf(Locale.ROOT,
                            "[PATH-RELINK] %.6f -> %.6f，评估=%d%n",
                            beforeRelinking, best.score, pathRelinkingEvaluations);
                }
                double beforeTaskPolish = best.score;
                TaskOrderPolishResult polished = taskOrderPolish(currentOrder, best, 80);
                best = polished.solution;
                if (best.score > beforeTaskPolish + EPS) {
                    System.out.printf(Locale.ROOT,
                            "[2/3-OPT] %.6f -> %.6f，评估=%d%n",
                            beforeTaskPolish, best.score, taskPolishEvaluations);
                }
                best = greedyInsertionPolish(best, 24);
                best = replacementAndExchangePolish(best);
            }
            System.out.printf(Locale.ROOT, "STAGE_TIME polish=%.3f%n",
                    (System.nanoTime() - polishStage) / 1_000_000_000.0);
            System.out.printf(Locale.ROOT,
                    "搜索阶段对比：initialScore=%.6f，随机重启=%d，GRASP初解=%d，大扰动=%d，深度毁坏重建=%d，独立重启=%d，精英解组合=%d，路径重连评估=%d，2/3-opt评估=%d，最终=%.6f%n",
                    initialScore, initialRestarts, graspInitials, largePerturbations, deepRuinRecreates, independentRestarts,
                    eliteMixes,
                    pathRelinkingEvaluations, taskPolishEvaluations, best.score);
            return best;
        }

        /**
         * GRASP初解构造：每一轮同时评估剩余任务和该任务的可行候选，
         * 将动态边际收益、任务稀缺度和资源多样性组合成自适应RCL。
         * mode用于生成不同偏好的初解，所有候选仍经过canAdd/add约束检查。
         */
        private GraspResult constructGrasp(int mode) {
            GreedyAlgorithm.Schedule schedule = emptySchedule();
            Set<String> coveredPoints = new HashSet<>();
            Map<String, List<GreedyAlgorithm.Observation>> areaSelections = new HashMap<>();
            Set<GreedyAlgorithm.Observation> used = Collections.newSetFromMap(new IdentityHashMap<>());
            Set<String> usedSatellites = new HashSet<>();
            List<GreedyAlgorithm.Task> remaining = new ArrayList<>(scenario.taskById.values());
            List<GreedyAlgorithm.Task> order = new ArrayList<>();

            while (!remaining.isEmpty()) {
                List<TaskChoice> choices = new ArrayList<>();
                for (GreedyAlgorithm.Task task : remaining) {
                    if (task.type == GreedyAlgorithm.TaskType.POINT && coveredPoints.contains(task.id)) continue;
                    if (task.type == GreedyAlgorithm.TaskType.AREA
                            && areaSelections.getOrDefault(task.id, List.of()).size() >= MAX_AREA_STRIPS) continue;
                    TaskChoice choice = bestTaskChoice(task, schedule, coveredPoints,
                            areaSelections, used, usedSatellites, mode);
                    if (choice != null && choice.gain > EPS) choices.add(choice);
                }
                if (choices.isEmpty()) break;
                choices.sort(Comparator.comparingDouble((TaskChoice c) -> -c.priority));
                int rclSize = Math.min(5, choices.size());
                int selectedIndex;
                if (mode % 3 == 0) {
                    selectedIndex = random.nextInt(rclSize);
                } else {
                    // 以排名倒数作为权重，保持高价值偏好，同时允许跳到次优任务。
                    double total = 0;
                    for (int i = 0; i < rclSize; i++) total += (rclSize - i);
                    double draw = random.nextDouble() * total;
                    selectedIndex = 0;
                    for (int i = 0; i < rclSize; i++) {
                        draw -= (rclSize - i);
                        if (draw <= 0) { selectedIndex = i; break; }
                    }
                }
                TaskChoice selected = choices.get(selectedIndex);
                remaining.remove(selected.task);
                if (add(selected.observation, schedule)) {
                    order.add(selected.task);
                    used.add(selected.observation);
                    usedSatellites.add(selected.observation.satelliteId);
                    coveredPoints.addAll(oracle.coveredPoints(selected.observation));
                    if (selected.task.type == GreedyAlgorithm.TaskType.AREA) {
                        areaSelections.computeIfAbsent(selected.task.id, k -> new ArrayList<>())
                                .add(selected.observation);
                    }
                }
            }
            improveAreas(schedule, coveredPoints, areaSelections, used, true);
            return new GraspResult(evaluate(schedule), order);
        }

        private TaskChoice bestTaskChoice(GreedyAlgorithm.Task task,
                                           GreedyAlgorithm.Schedule schedule,
                                           Set<String> coveredPoints,
                                           Map<String, List<GreedyAlgorithm.Observation>> areaSelections,
                                           Set<GreedyAlgorithm.Observation> used,
                                           Set<String> usedSatellites,
                                           int mode) {
            List<TaskChoice> candidates = new ArrayList<>();
            int checked = 0;
            for (GreedyAlgorithm.Observation observation : catalog.candidates(task.id)) {
                if (used.contains(observation)) continue;
                double gain = marginal(observation, task, coveredPoints, areaSelections);
                if (gain <= EPS || !canAdd(observation, schedule)) continue;
                double density = gain / Math.max(1, observation.duration());
                double scarcity = task.score / Math.max(1, catalog.rawCount(task.id));
                double priority = density;
                if (mode % 4 == 1) priority += 0.55 * scarcity;
                if (mode % 4 == 2) priority += 0.35 * scarcity
                        + (usedSatellites.contains(observation.satelliteId) ? 0.0 : 0.20 * density);
                if (mode % 4 == 3) priority += 0.25 * task.score
                        / Math.max(1, catalog.rawCount(task.id));
                candidates.add(new TaskChoice(task, observation, gain, priority));
                if (++checked >= 64) break;
            }
            if (candidates.isEmpty()) return null;
            candidates.sort(Comparator.comparingDouble((TaskChoice c) -> -c.priority));
            // 任务的候选也使用小RCL，避免每个任务永远选择同一条带。
            int rcl = Math.min(3, candidates.size());
            return candidates.get(mode % 5 == 0 ? random.nextInt(rcl) : 0);
        }

        /**
         * 全局边际收益初解。候选观测的主任务只决定区域并集收益，
         * 点任务收益则由该观测实际覆盖的所有点任务共同计算。
         */
        private GraspResult constructGlobalMarginal(int mode) {
            GreedyAlgorithm.Schedule schedule = emptySchedule();
            Set<String> coveredPoints = new HashSet<>();
            Map<String, List<GreedyAlgorithm.Observation>> areaSelections = new HashMap<>();
            Set<GreedyAlgorithm.Observation> used = Collections.newSetFromMap(new IdentityHashMap<>());
            Set<String> usedSatellites = new HashSet<>();
            Set<String> usedTaskIds = new LinkedHashSet<>();
            int maxAdds = Math.min(420, Math.max(80, scenario.taskById.size() * 2));

            for (int step = 0; step < maxAdds; step++) {
                List<GlobalChoice> choices = new ArrayList<>();
                for (GreedyAlgorithm.Task task : scenario.taskById.values()) {
                    // 点任务只允许一个主观测；顺带覆盖其他点任务的收益仍由marginal计算。
                    if (task.type == GreedyAlgorithm.TaskType.POINT
                            && coveredPoints.contains(task.id)) continue;
                    if (task.type == GreedyAlgorithm.TaskType.AREA
                            && areaSelections.getOrDefault(task.id, List.of()).size() >= MAX_AREA_STRIPS) continue;
                    List<GreedyAlgorithm.Observation> options = catalog.candidates(task.id);
                    int checked = 0;
                    for (GreedyAlgorithm.Observation observation : options) {
                        if (used.contains(observation)) continue;
                        double gain = marginal(observation, task, coveredPoints, areaSelections);
                        if (gain <= EPS || !canAdd(observation, schedule)) continue;
                        double density = gain / Math.max(1, observation.duration());
                        double scarcity = task.score / Math.max(1, catalog.rawCount(task.id));
                        double priority = density;
                        if (mode % 3 == 1) priority += 0.55 * scarcity;
                        if (mode % 3 == 2 && !usedSatellites.contains(observation.satelliteId)) {
                            priority += 0.18 * density;
                        }
                        choices.add(new GlobalChoice(task, observation, gain, priority));
                        if (++checked >= 64) break;
                    }
                }
                if (choices.isEmpty()) break;
                choices.sort(Comparator.comparingDouble((GlobalChoice c) -> -c.priority));
                int rclSize = Math.min(8, choices.size());
                int pick = mode == 0 ? random.nextInt(rclSize) : 0;
                GlobalChoice selected = choices.get(pick);
                if (!add(selected.observation, schedule)) break;
                used.add(selected.observation);
                usedSatellites.add(selected.observation.satelliteId);
                usedTaskIds.add(selected.task.id);
                coveredPoints.addAll(oracle.coveredPoints(selected.observation));
                if (selected.task.type == GreedyAlgorithm.TaskType.AREA) {
                    areaSelections.computeIfAbsent(selected.task.id, k -> new ArrayList<>())
                            .add(selected.observation);
                }
            }
            improveAreas(schedule, coveredPoints, areaSelections, used, true);
            List<GreedyAlgorithm.Task> order = new ArrayList<>();
            for (GreedyAlgorithm.Task task : scenario.taskById.values()) {
                if (usedTaskIds.contains(task.id)) order.add(task);
            }
            for (GreedyAlgorithm.Task task : scenario.taskById.values()) {
                if (!usedTaskIds.contains(task.id)) order.add(task);
            }
            return new GraspResult(evaluate(schedule), order);
        }

        /**
         * 精英解池：保留少量高收益且观测集合差异较大的方案。
         * 结构差异比单纯分数排序更重要，否则解池会退化成同一个局部最优的复制品。
         */
        private void rememberElite(Solution solution) {
            List<GreedyAlgorithm.Observation> snapshot = new ArrayList<>(solution.schedule.observations);
            for (EliteEntry existing : eliteArchive) {
                if (sameObservationSet(existing.observations, snapshot)) return;
            }
            // 使用原有口径计算一次快照收益，避免排序比较器反复重建同一个方案。
            eliteArchive.add(new EliteEntry(snapshot, snapshotScore(snapshot)));
            eliteArchive.sort((a, b) -> Double.compare(b.score, a.score));
            while (eliteArchive.size() > 6) {
                // 低分且与其他解最相似的方案优先淘汰，保留结构多样性。
                int remove = eliteArchive.size() - 1;
                double worstDistance = Double.POSITIVE_INFINITY;
                for (int i = 0; i < eliteArchive.size(); i++) {
                    double minDistance = Double.POSITIVE_INFINITY;
                    for (int j = 0; j < eliteArchive.size(); j++) {
                        if (i == j) continue;
                        minDistance = Math.min(minDistance,
                                1.0 - jaccard(eliteArchive.get(i).observations,
                                        eliteArchive.get(j).observations));
                    }
                    if (minDistance < worstDistance
                            || (Math.abs(minDistance - worstDistance) < EPS
                            && i > remove)) {
                        worstDistance = minDistance;
                        remove = i;
                    }
                }
                eliteArchive.remove(remove);
            }
        }

        private double snapshotScore(List<GreedyAlgorithm.Observation> observations) {
            return evaluate(rebuildPermissive(observations)).score;
        }

        private static boolean sameObservationSet(List<GreedyAlgorithm.Observation> a,
                                                   List<GreedyAlgorithm.Observation> b) {
            if (a.size() != b.size()) return false;
            Set<GreedyAlgorithm.Observation> set = Collections.newSetFromMap(new IdentityHashMap<>());
            set.addAll(a);
            for (GreedyAlgorithm.Observation observation : b) {
                if (!set.contains(observation)) return false;
            }
            return true;
        }

        private static double jaccard(List<GreedyAlgorithm.Observation> a,
                                      List<GreedyAlgorithm.Observation> b) {
            Set<GreedyAlgorithm.Observation> union = Collections.newSetFromMap(new IdentityHashMap<>());
            union.addAll(a);
            union.addAll(b);
            if (union.isEmpty()) return 1.0;
            Set<GreedyAlgorithm.Observation> intersection = Collections.newSetFromMap(new IdentityHashMap<>());
            intersection.addAll(a);
            intersection.retainAll(b);
            return (double) intersection.size() / union.size();
        }

        /**
         * 从两个精英解中按概率取观测，混合后重新插入。冲突观测被跳过，
         * 随后用Regret-2和普通修复补足资源空隙，所有插入继续经过统一约束检查。
         */
        private Solution eliteRecombine() {
            if (eliteArchive.size() < 2) return evaluate(emptySchedule());
            int first = random.nextInt(eliteArchive.size());
            int second = random.nextInt(eliteArchive.size() - 1);
            if (second >= first) second++;
            List<GreedyAlgorithm.Observation> pool = new ArrayList<>();
            Set<GreedyAlgorithm.Observation> seen = Collections.newSetFromMap(new IdentityHashMap<>());
            for (GreedyAlgorithm.Observation observation : eliteArchive.get(first).observations) {
                if (random.nextDouble() < 0.62 && seen.add(observation)) pool.add(observation);
            }
            for (GreedyAlgorithm.Observation observation : eliteArchive.get(second).observations) {
                if (random.nextDouble() < 0.62 && seen.add(observation)) pool.add(observation);
            }
            Collections.shuffle(pool, random);
            GreedyAlgorithm.Schedule schedule = emptySchedule();
            Set<String> usedPointTasks = new HashSet<>();
            for (GreedyAlgorithm.Observation observation : pool) {
                GreedyAlgorithm.Task main = scenario.taskById.get(observation.taskId);
                if (main != null && main.type == GreedyAlgorithm.TaskType.POINT
                        && usedPointTasks.contains(main.id)) continue;
                if (add(observation, schedule)
                        && main != null && main.type == GreedyAlgorithm.TaskType.POINT) {
                    usedPointTasks.add(main.id);
                }
            }
            Solution partial = evaluate(schedule);
            Set<String> coveredPoints = new HashSet<>(partial.pointCovered);
            Map<String, List<GreedyAlgorithm.Observation>> areaSelections = new HashMap<>();
            Set<GreedyAlgorithm.Observation> used = Collections.newSetFromMap(new IdentityHashMap<>());
            used.addAll(schedule.observations);
            for (GreedyAlgorithm.Observation observation : schedule.observations) {
                GreedyAlgorithm.Task task = scenario.taskById.get(observation.taskId);
                if (task != null && task.type == GreedyAlgorithm.TaskType.AREA) {
                    areaSelections.computeIfAbsent(task.id, k -> new ArrayList<>()).add(observation);
                }
            }
            regretRepair(schedule, coveredPoints, areaSelections, used, Math.max(8, pool.size() / 3));
            improveAreas(schedule, coveredPoints, areaSelections, used, true);
            return evaluate(schedule);
        }

        /** 允许跳过冲突继续插入，用于精英解组合；与严格rebuild不同，不会遇到第一处冲突就停止。 */
        private GreedyAlgorithm.Schedule rebuildPermissive(
                List<GreedyAlgorithm.Observation> observations) {
            List<GreedyAlgorithm.Observation> sorted = new ArrayList<>(observations);
            sorted.sort(Comparator.comparingLong(o -> o.start));
            GreedyAlgorithm.Schedule schedule = emptySchedule();
            for (GreedyAlgorithm.Observation observation : sorted) add(observation, schedule);
            return schedule;
        }

        /**
         * 大规模任务顺序扰动：删除当前排列的35%到60%，再随机插回。
         * 它改变的是构造顺序，随后由construct从空调度重新分配观测和数传，
         * 因而可以跳出当前观测组合对应的局部盆地。
         */
        private List<GreedyAlgorithm.Task> largeOrderPerturbation(
                List<GreedyAlgorithm.Task> source) {
            List<GreedyAlgorithm.Task> kept = new ArrayList<>(source);
            List<GreedyAlgorithm.Task> removed = new ArrayList<>();
            int q = Math.max(8, (int) Math.round(kept.size()
                    * (0.35 + random.nextDouble() * 0.25)));
            Collections.shuffle(kept, random);
            while (removed.size() < q && !kept.isEmpty()) {
                removed.add(kept.remove(kept.size() - 1));
            }
            Collections.shuffle(removed, random);
            for (GreedyAlgorithm.Task task : removed) {
                int position = random.nextInt(kept.size() + 1);
                kept.add(position, task);
            }
            return kept;
        }

        /**
         * 独立重启顺序：用覆盖潜力、收益/候选稀缺度和随机噪声重新排序，
         * 不继承current的局部任务顺序，专门用于检验初始解盆地是否过强。
         */
        private List<GreedyAlgorithm.Task> independentRestartOrder() {
            List<GreedyAlgorithm.Task> order = new ArrayList<>(scenario.taskById.values());
            Map<GreedyAlgorithm.Task, Double> priorities = new IdentityHashMap<>();
            for (GreedyAlgorithm.Task task : order) {
                double scarcity = task.score / Math.max(1, catalog.rawCount(task.id));
                double potential = catalog.taskPotential(task.id);
                double noise = random.nextDouble() * Math.max(1.0, task.score * 0.35);
                priorities.put(task, 0.55 * potential + 0.30 * scarcity + 0.15 * task.score + noise);
            }
            order.sort(Comparator.comparingDouble(priorities::get).reversed());
            return order;
        }

        /**
         * 深度毁坏-重建（Iterated Greedy 的 ruin-and-recreate 阶段）。
         * 与普通destroyRepair相比，移除比例显著更大，并且使用新的随机任务顺序修复，
         * 直接改变观测、数传和姿态组合；剩余方案和所有新插入仍经过统一约束检查。
         */
        private Solution deepDestroyRepair(Solution base) {
            List<GreedyAlgorithm.Observation> source = new ArrayList<>(base.schedule.observations);
            if (source.isEmpty()) return base;
            int q = Math.max(8, (int) Math.round(source.size()
                    * (0.35 + random.nextDouble() * 0.25)));
            q = Math.min(q, Math.max(8, source.size() - 1));

            Map<GreedyAlgorithm.Observation, Double> loss = marginalContributions(base);
            source.sort(Comparator.comparingDouble((GreedyAlgorithm.Observation o) ->
                    loss.getOrDefault(o, 0.0) / Math.max(1, o.duration())));
            Set<GreedyAlgorithm.Observation> removed = Collections.newSetFromMap(new IdentityHashMap<>());
            int randomPart = Math.min(q, Math.max(1, q / 2));
            for (int i = 0; i < randomPart; i++) {
                int index = random.nextInt(source.size());
                removed.add(source.get(index));
            }
            for (GreedyAlgorithm.Observation observation : source) {
                if (removed.size() >= q) break;
                removed.add(observation);
            }

            GreedyAlgorithm.Schedule partial = emptySchedule();
            for (GreedyAlgorithm.Observation observation : base.schedule.observations) {
                if (!removed.contains(observation)) add(observation, partial);
            }
            Solution partialSolution = evaluate(partial);
            Set<String> coveredPoints = new HashSet<>(partialSolution.pointCovered);
            Map<String, List<GreedyAlgorithm.Observation>> areaSelections = new HashMap<>();
            Set<GreedyAlgorithm.Observation> used = Collections.newSetFromMap(new IdentityHashMap<>());
            used.addAll(partial.observations);
            for (GreedyAlgorithm.Observation observation : partial.observations) {
                GreedyAlgorithm.Task task = scenario.taskById.get(observation.taskId);
                if (task != null && task.type == GreedyAlgorithm.TaskType.AREA) {
                    areaSelections.computeIfAbsent(task.id, k -> new ArrayList<>()).add(observation);
                }
            }

            // 先处理候选稀缺的任务，再用随机顺序扩大组合差异。
            List<GreedyAlgorithm.Task> repairTasks = independentRestartOrder();
            if (repairTasks.size() > 1) {
                int prefix = Math.min(repairTasks.size(), 80);
                Collections.shuffle(repairTasks.subList(0, prefix), random);
            }
            regretRepair(partial, coveredPoints, areaSelections, used, removed.size());
            for (GreedyAlgorithm.Task task : repairTasks) {
                if (task.type == GreedyAlgorithm.TaskType.POINT && coveredPoints.contains(task.id)) continue;
                if (task.type == GreedyAlgorithm.TaskType.AREA
                        && areaSelections.getOrDefault(task.id, List.of()).size() >= MAX_AREA_STRIPS) continue;
                GreedyAlgorithm.Observation chosen = chooseCandidate(
                        task, partial, coveredPoints, areaSelections, used, true);
                if (chosen != null && add(chosen, partial)) {
                    used.add(chosen);
                    coveredPoints.addAll(oracle.coveredPoints(chosen));
                    if (task.type == GreedyAlgorithm.TaskType.AREA) {
                        areaSelections.computeIfAbsent(task.id, k -> new ArrayList<>()).add(chosen);
                    }
                }
            }
            improveAreas(partial, coveredPoints, areaSelections, used, true);
            return evaluate(partial);
        }

        /**
         * 路径重连：从一个任务排列逐步交换为另一个排列，每一步都完整重建可行调度。
         * 这是任务优先级层面的重连，不直接修改观测/数传，因此约束仍由construct/add统一检查。
         */
        private Solution pathRelinking(List<GreedyAlgorithm.Task> from,
                                       List<GreedyAlgorithm.Task> to,
                                       Solution incumbent, int maxSteps) {
            List<GreedyAlgorithm.Task> working = new ArrayList<>(from);
            Solution best = incumbent;
            int steps = 0;
            int limit = Math.min(maxSteps, working.size());
            for (int position = 0; position < working.size() && steps < limit; position++) {
                GreedyAlgorithm.Task target = to.get(position);
                int targetIndex = indexOfTask(working, target, position);
                if (targetIndex < 0 || targetIndex == position) continue;
                Collections.swap(working, position, targetIndex);
                Solution candidate = construct(working, false);
                pathRelinkingEvaluations++;
                steps++;
                if (candidate.score > best.score + EPS) best = candidate;
            }
            return best;
        }

        private static int indexOfTask(List<GreedyAlgorithm.Task> order,
                                       GreedyAlgorithm.Task target, int fromIndex) {
            for (int i = Math.max(0, fromIndex); i < order.size(); i++) {
                if (order.get(i).id.equals(target.id)) return i;
            }
            return -1;
        }

        /**
         * 任务顺序局部重建：有限次数的2-opt反转和3-opt片段重排。
         * 每次候选都调用construct，接受规则只保留严格增益，避免把局部搜索变成违规修补。
         */
        private TaskOrderPolishResult taskOrderPolish(List<GreedyAlgorithm.Task> seedOrder,
                                                       Solution incumbent, int budget) {
            List<GreedyAlgorithm.Task> order = new ArrayList<>(seedOrder);
            Solution best = incumbent;
            int evaluations = 0;
            int n = order.size();
            int window = Math.min(n, 96);
            boolean improved = true;
            while (improved && evaluations < budget) {
                improved = false;
                // 2-opt：只扫描短距离片段，防止小场景后处理占满运行时间。
                for (int i = 0; i < window - 1 && evaluations < budget; i++) {
                    int maxJ = Math.min(window - 1, i + 10);
                    for (int j = i + 1; j <= maxJ && evaluations < budget; j++) {
                        List<GreedyAlgorithm.Task> candidateOrder = new ArrayList<>(order);
                        Collections.reverse(candidateOrder.subList(i, j + 1));
                        Solution candidate = construct(candidateOrder, false);
                        evaluations++;
                        if (candidate.score > best.score + EPS) {
                            best = candidate;
                            order = candidateOrder;
                            improved = true;
                        }
                    }
                }
                // 3-opt：抽取三个切点，尝试两种非重复片段顺序。
                for (int i = 0; i + 3 < window && evaluations < budget; i += 3) {
                    for (int j = i + 1; j + 2 < window && evaluations < budget; j += 3) {
                        for (int k = j + 1; k + 1 < window && evaluations < budget; k += 3) {
                            List<GreedyAlgorithm.Task> candidateOrder = threeOptSwap(order, i, j, k, false);
                            Solution candidate = construct(candidateOrder, false);
                            evaluations++;
                            if (candidate.score > best.score + EPS) {
                                best = candidate;
                                order = candidateOrder;
                                improved = true;
                            }
                            if (evaluations >= budget) break;
                            candidateOrder = threeOptSwap(order, i, j, k, true);
                            candidate = construct(candidateOrder, false);
                            evaluations++;
                            if (candidate.score > best.score + EPS) {
                                best = candidate;
                                order = candidateOrder;
                                improved = true;
                            }
                        }
                    }
                }
            }
            taskPolishEvaluations += evaluations;
            return new TaskOrderPolishResult(order, best);
        }

        private static List<GreedyAlgorithm.Task> threeOptSwap(List<GreedyAlgorithm.Task> source,
                                                                int i, int j, int k,
                                                                boolean alternate) {
            List<GreedyAlgorithm.Task> result = new ArrayList<>(source.size());
            result.addAll(source.subList(0, i));
            List<GreedyAlgorithm.Task> a = new ArrayList<>(source.subList(i, j));
            List<GreedyAlgorithm.Task> b = new ArrayList<>(source.subList(j, k));
            List<GreedyAlgorithm.Task> c = new ArrayList<>(source.subList(k, source.size()));
            if (alternate) {
                Collections.reverse(a);
                Collections.reverse(b);
                result.addAll(b);
                result.addAll(a);
            } else {
                result.addAll(b);
                result.addAll(a);
            }
            result.addAll(c);
            return result;
        }

        /**
         * 小场景局部强化：
         * 1) 单观测替换：保留其他观测，尝试同一主任务的另一条合法候选；
         * 2) 两观测联合交换：同时移除两个观测，再为两个主任务选择新的候选。
         * 每个试解都重新按时间排序并走add()，因此不会绕过姿态、数传和轨道约束。
         */
        private Solution replacementAndExchangePolish(Solution base) {
            Solution current = base;
            for (int round = 0; round < 2; round++) {
                Solution replacement = bestSingleReplacement(current);
                if (replacement.score > current.score + EPS) current = replacement;
                Solution exchange = bestPairExchange(current);
                if (exchange.score > current.score + EPS) current = exchange;
                if (replacement.score <= current.score + EPS
                        && exchange.score <= current.score + EPS) break;
            }
            return current;
        }

        private Solution bestSingleReplacement(Solution base) {
            Solution best = base;
            List<GreedyAlgorithm.Observation> source = new ArrayList<>(base.schedule.observations);
            for (GreedyAlgorithm.Observation old : source) {
                List<GreedyAlgorithm.Observation> alternatives = rankedAlternatives(old.taskId, old, 24);
                for (GreedyAlgorithm.Observation alternative : alternatives) {
                    List<GreedyAlgorithm.Observation> selected = new ArrayList<>(source);
                    selected.remove(old);
                    if (containsIdentity(selected, alternative)) continue;
                    selected.add(alternative);
                    GreedyAlgorithm.Schedule trial = rebuild(selected);
                    if (trial.observations.size() != selected.size()) continue;
                    Solution candidate = evaluate(trial);
                    if (candidate.score > best.score + EPS) best = candidate;
                }
            }
            return best;
        }

        private Solution bestPairExchange(Solution base) {
            List<GreedyAlgorithm.Observation> source = new ArrayList<>(base.schedule.observations);
            Map<GreedyAlgorithm.Observation, Double> loss = marginalContributions(base);
            source.sort(Comparator.comparingDouble(o -> loss.getOrDefault(o, 0.0)));
            int pairLimit = Math.min(18, source.size());
            Solution best = base;
            for (int i = 0; i < pairLimit; i++) {
                GreedyAlgorithm.Observation first = source.get(i);
                List<GreedyAlgorithm.Observation> firstAlternatives = rankedAlternatives(first.taskId, first, 8);
                for (int j = i + 1; j < pairLimit; j++) {
                    GreedyAlgorithm.Observation second = source.get(j);
                    List<GreedyAlgorithm.Observation> secondAlternatives = rankedAlternatives(second.taskId, second, 8);
                    for (GreedyAlgorithm.Observation a : firstAlternatives) {
                        for (GreedyAlgorithm.Observation b : secondAlternatives) {
                            if (a == b) continue;
                            List<GreedyAlgorithm.Observation> selected = new ArrayList<>(source);
                            selected.remove(first);
                            selected.remove(second);
                            if (containsIdentity(selected, a) || containsIdentity(selected, b)) continue;
                            selected.add(a);
                            selected.add(b);
                            GreedyAlgorithm.Schedule trial = rebuild(selected);
                            if (trial.observations.size() != selected.size()) continue;
                            Solution candidate = evaluate(trial);
                            if (candidate.score > best.score + EPS) best = candidate;
                        }
                    }
                }
            }
            return best;
        }

        private List<GreedyAlgorithm.Observation> rankedAlternatives(String taskId,
                                                                      GreedyAlgorithm.Observation old,
                                                                      int limit) {
            List<GreedyAlgorithm.Observation> result = new ArrayList<>();
            for (GreedyAlgorithm.Observation candidate : catalog.candidates(taskId)) {
                if (candidate != old) result.add(candidate);
            }
            result.sort(Comparator.comparingDouble(this::standaloneContribution).reversed());
            return result.size() <= limit ? result : new ArrayList<>(result.subList(0, limit));
        }

        private GreedyAlgorithm.Schedule rebuild(List<GreedyAlgorithm.Observation> observations) {
            List<GreedyAlgorithm.Observation> sorted = new ArrayList<>(observations);
            sorted.sort(Comparator.comparingLong(o -> o.start));
            GreedyAlgorithm.Schedule schedule = emptySchedule();
            for (GreedyAlgorithm.Observation observation : sorted) {
                if (!add(observation, schedule)) return schedule;
            }
            return schedule;
        }

        private static boolean containsIdentity(List<GreedyAlgorithm.Observation> observations,
                                                GreedyAlgorithm.Observation target) {
            for (GreedyAlgorithm.Observation observation : observations) {
                if (observation == target) return true;
            }
            return false;
        }

        private Solution greedyInsertionPolish(Solution base, int maxAdds) {
            Solution current = base;
            Set<GreedyAlgorithm.Observation> used = Collections.newSetFromMap(new IdentityHashMap<>());
            used.addAll(current.schedule.observations);
            for (int insertion = 0; insertion < maxAdds; insertion++) {
                Set<String> coveredPoints = new HashSet<>(current.pointCovered);
                Map<String, List<GreedyAlgorithm.Observation>> areaSelections = new HashMap<>();
                for (GreedyAlgorithm.Observation observation : current.schedule.observations) {
                    GreedyAlgorithm.Task task = scenario.taskById.get(observation.taskId);
                    if (task != null && task.type == GreedyAlgorithm.TaskType.AREA) {
                        areaSelections.computeIfAbsent(task.id, k -> new ArrayList<>()).add(observation);
                    }
                }
                GreedyAlgorithm.Observation bestCandidate = null;
                double bestGain = EPS;
                for (GreedyAlgorithm.Task task : scenario.taskById.values()) {
                    if (task.type == GreedyAlgorithm.TaskType.POINT && coveredPoints.contains(task.id)) continue;
                    if (task.type == GreedyAlgorithm.TaskType.AREA
                            && areaSelections.getOrDefault(task.id, List.of()).size() >= MAX_AREA_STRIPS) continue;
                    for (GreedyAlgorithm.Observation candidate : catalog.candidates(task.id)) {
                        if (used.contains(candidate) || !canAdd(candidate, current.schedule)) continue;
                        double gain = marginal(candidate, task, coveredPoints, areaSelections);
                        if (gain > bestGain) {
                            bestGain = gain;
                            bestCandidate = candidate;
                        }
                    }
                }
                if (bestCandidate == null || !add(bestCandidate, current.schedule)) break;
                used.add(bestCandidate);
                current = evaluate(current.schedule);
            }
            return current;
        }

        String operatorSummary(String[] names, boolean destroy) {
            int[] uses = destroy ? totalDestroyUses : totalRepairUses;
            StringBuilder result = new StringBuilder();
            for (int i = 0; i < names.length; i++) {
                if (i > 0) result.append(", ");
                result.append(names[i]).append('=').append(uses[i]);
            }
            return result.toString();
        }

        private Solution destroyRepair(Solution base, int destroy, int repair) {
            // 直接从当前解删除一批观测，再用指定修复策略回填。
            // 这是ALNS的核心邻域：删除越相关的一组观测，越容易释放出连续资源窗口。
            List<GreedyAlgorithm.Observation> observations = new ArrayList<>(base.schedule.observations);
            if (observations.isEmpty()) return base;
            int maxNeighborhood = Math.min(80, Math.max(18,
                    (int) Math.ceil(2.0 * Math.sqrt(observations.size()))));
            int q = Math.max(2, Math.min(maxNeighborhood,
                    (int) Math.round(observations.size() * (0.03 + random.nextDouble() * 0.09))));
            Set<GreedyAlgorithm.Observation> removed = Collections.newSetFromMap(new IdentityHashMap<>());
            GreedyAlgorithm.Task forcedTask = null;
            GreedyAlgorithm.Observation forcedObservation = null;

            if (destroy == 0) {
                // 随机破坏：保持探索能力，避免搜索只围绕当前最优解。
                List<GreedyAlgorithm.Observation> shuffled = new ArrayList<>(observations);
                Collections.shuffle(shuffled, random);
                removed.addAll(shuffled.subList(0, Math.min(q, shuffled.size())));
            } else if (destroy == 1) {
                // 边际损失破坏：优先删除“独立贡献小”的观测，尽量少损失当前收益。
                Map<GreedyAlgorithm.Observation, Double> contributions = marginalContributions(base);
                observations.sort(Comparator.comparingDouble(o ->
                        contributions.getOrDefault(o, 0.0) / Math.max(1, o.duration())));
                removed.addAll(observations.subList(0, Math.min(q, observations.size())));
            } else if (destroy == 2) {
                // 未覆盖任务破坏：围绕一个仍有候选但尚未覆盖的点任务释放附近冲突资源。
                List<GreedyAlgorithm.Task> uncovered = new ArrayList<>();
                for (GreedyAlgorithm.Task task : scenario.pointTasks) {
                    if (!base.pointCovered.contains(task.id) && !catalog.candidates(task.id).isEmpty()) {
                        uncovered.add(task);
                    }
                }
                uncovered.sort(Comparator.comparingDouble((GreedyAlgorithm.Task t) -> -t.score));
                if (!uncovered.isEmpty()) {
                    forcedTask = uncovered.get(random.nextInt(Math.min(20, uncovered.size())));
                    List<GreedyAlgorithm.Observation> options = catalog.candidates(forcedTask.id);
                    GreedyAlgorithm.Observation seed = options.get(random.nextInt(Math.min(24, options.size())));
                    forcedObservation = seed;
                    for (GreedyAlgorithm.Observation observation : observations) {
                        if (observation.satelliteId.equals(seed.satelliteId)
                                && Math.abs(observation.start - seed.start) <= 600) {
                            removed.add(observation);
                        }
                    }
                    observations.sort(Comparator.comparingLong(o -> observationRelatedness(seed, o)));
                    for (GreedyAlgorithm.Observation observation : observations) {
                        if (removed.size() >= q) break;
                        removed.add(observation);
                    }
                } else {
                    GreedyAlgorithm.Observation seed = observations.get(random.nextInt(observations.size()));
                    observations.sort(Comparator.comparingLong(o -> observationRelatedness(seed, o)));
                    removed.addAll(observations.subList(0, Math.min(q, observations.size())));
                }
            } else if (destroy == 3) {
                // Shaw破坏：按卫星、时间、轨道和姿态相似性删除相关观测。
                GreedyAlgorithm.Observation seed = observations.get(random.nextInt(observations.size()));
                observations.sort(Comparator.comparingDouble(o -> shawRelatedness(seed, o)));
                removed.addAll(observations.subList(0, Math.min(q, observations.size())));
            } else {
                // 卫星-轨道块破坏：删除同一卫星同一轨道的观测，针对轨道工作时长瓶颈。
                GreedyAlgorithm.Observation seed = observations.get(random.nextInt(observations.size()));
                int seedOrbit = orbit(seed);
                for (GreedyAlgorithm.Observation observation : observations) {
                    if (observation.satelliteId.equals(seed.satelliteId)
                            && orbit(observation) == seedOrbit) {
                        removed.add(observation);
                    }
                }
                observations.sort(Comparator.comparingDouble(o -> shawRelatedness(seed, o)));
                for (GreedyAlgorithm.Observation observation : observations) {
                    if (removed.size() >= q) break;
                    removed.add(observation);
                }
            }

            GreedyAlgorithm.Schedule partial = emptySchedule();
            Set<GreedyAlgorithm.Observation> used = Collections.newSetFromMap(new IdentityHashMap<>());
            for (GreedyAlgorithm.Observation observation : base.schedule.observations) {
                if (!removed.contains(observation) && add(observation, partial)) used.add(observation);
            }

            Solution partialSolution = evaluate(partial);
            Set<String> coveredPoints = new HashSet<>(partialSolution.pointCovered);
            Map<String, List<GreedyAlgorithm.Observation>> areaSelections = new HashMap<>();
            for (GreedyAlgorithm.Observation observation : partial.observations) {
                GreedyAlgorithm.Task task = scenario.taskById.get(observation.taskId);
                if (task != null && task.type == GreedyAlgorithm.TaskType.AREA) {
                    areaSelections.computeIfAbsent(task.id, k -> new ArrayList<>()).add(observation);
                }
            }

            List<GreedyAlgorithm.Task> repairTasks = new ArrayList<>(scenario.taskById.values());
            if (repair == 0) {
                repairTasks.sort(Comparator.comparingDouble((GreedyAlgorithm.Task t) -> -t.score));
            } else if (repair == 1) {
                repairTasks.sort(Comparator.comparingDouble((GreedyAlgorithm.Task t) ->
                        -t.score / Math.max(1, catalog.rawCount(t.id))));
            } else if (repair == 2) {
                repairTasks.sort(Comparator.comparingDouble((GreedyAlgorithm.Task t) -> -catalog.taskPotential(t.id)));
                int prefix = Math.min(30, repairTasks.size());
                Collections.shuffle(repairTasks.subList(0, prefix), random);
            } else {
                repairTasks.sort(Comparator.comparingDouble((GreedyAlgorithm.Task t) ->
                        -catalog.taskPotential(t.id) / Math.sqrt(Math.max(1, catalog.rawCount(t.id)))));
            }

            if (forcedTask != null && !coveredPoints.contains(forcedTask.id)) {
                GreedyAlgorithm.Observation chosen = forcedObservation != null
                        && !used.contains(forcedObservation) && canAdd(forcedObservation, partial)
                        ? forcedObservation
                        : chooseCandidate(forcedTask, partial, coveredPoints, areaSelections, used, false);
                if (chosen != null && add(chosen, partial)) {
                    used.add(chosen);
                    coveredPoints.addAll(oracle.coveredPoints(chosen));
                }
            }

            if (repair == 3) {
                regretRepair(partial, coveredPoints, areaSelections, used, q);
            }

            for (GreedyAlgorithm.Task task : repairTasks) {
                if (task.type == GreedyAlgorithm.TaskType.POINT && coveredPoints.contains(task.id)) continue;
                GreedyAlgorithm.Observation chosen = chooseCandidate(
                        task, partial, coveredPoints, areaSelections, used, false);
                if (chosen != null && add(chosen, partial)) {
                    used.add(chosen);
                    coveredPoints.addAll(oracle.coveredPoints(chosen));
                    if (task.type == GreedyAlgorithm.TaskType.AREA) {
                        areaSelections.computeIfAbsent(task.id, k -> new ArrayList<>()).add(chosen);
                    }
                }
            }
            improveAreas(partial, coveredPoints, areaSelections, used, false);
            return evaluate(partial);
        }

        private double standaloneContribution(GreedyAlgorithm.Observation observation) {
            double value = 0;
            for (String id : oracle.coveredPoints(observation)) value += scenario.taskById.get(id).score;
            GreedyAlgorithm.Task task = scenario.taskById.get(observation.taskId);
            if (task != null && task.type == GreedyAlgorithm.TaskType.AREA) {
                value += task.score * oracle.areaRatio(task, List.of(observation));
            }
            return value / Math.max(1, observation.duration());
        }

        private Map<GreedyAlgorithm.Observation, Double> marginalContributions(Solution solution) {
            Map<GreedyAlgorithm.Observation, Double> result = new IdentityHashMap<>();
            Map<String, Integer> pointCounts = new HashMap<>();
            Map<String, List<GreedyAlgorithm.Observation>> areaObservations = new HashMap<>();
            for (GreedyAlgorithm.Observation observation : solution.schedule.observations) {
                result.put(observation, 0.0);
                for (String point : oracle.coveredPoints(observation)) {
                    pointCounts.merge(point, 1, Integer::sum);
                }
                GreedyAlgorithm.Task task = scenario.taskById.get(observation.taskId);
                if (task != null && task.type == GreedyAlgorithm.TaskType.AREA) {
                    areaObservations.computeIfAbsent(task.id, k -> new ArrayList<>()).add(observation);
                }
            }
            for (GreedyAlgorithm.Observation observation : solution.schedule.observations) {
                double loss = 0;
                for (String point : oracle.coveredPoints(observation)) {
                    if (pointCounts.getOrDefault(point, 0) == 1) {
                        loss += scenario.taskById.get(point).score;
                    }
                }
                result.put(observation, loss);
            }
            for (Map.Entry<String, List<GreedyAlgorithm.Observation>> entry : areaObservations.entrySet()) {
                GreedyAlgorithm.Task task = scenario.taskById.get(entry.getKey());
                List<GreedyAlgorithm.Observation> strips = entry.getValue();
                double full = oracle.areaRatio(task, strips);
                for (GreedyAlgorithm.Observation observation : strips) {
                    List<GreedyAlgorithm.Observation> without = new ArrayList<>(strips);
                    without.remove(observation);
                    double areaLoss = task.score * Math.max(0, full - oracle.areaRatio(task, without));
                    result.merge(observation, areaLoss, Double::sum);
                }
            }
            return result;
        }

        private static long observationRelatedness(GreedyAlgorithm.Observation a,
                                                    GreedyAlgorithm.Observation b) {
            long satellitePenalty = a.satelliteId.equals(b.satelliteId) ? 0 : 43_200;
            return satellitePenalty + Math.abs(a.start - b.start);
        }

        private static double shawRelatedness(GreedyAlgorithm.Observation a,
                                              GreedyAlgorithm.Observation b) {
            double relation = Math.abs(a.start - b.start) / 60.0;
            if (!a.satelliteId.equals(b.satelliteId)) relation += 720.0;
            if (orbit(a) != orbit(b)) relation += 180.0;
            if (a.type != b.type) relation += 60.0;
            relation += 2.0 * Math.abs(a.roll - b.roll) + Math.abs(a.pitch - b.pitch);
            return relation;
        }

        private static int orbit(GreedyAlgorithm.Observation observation) {
            return (int) (observation.start / 5400L);
        }

        private void regretRepair(GreedyAlgorithm.Schedule schedule, Set<String> coveredPoints,
                                  Map<String, List<GreedyAlgorithm.Observation>> areaSelections,
                                  Set<GreedyAlgorithm.Observation> used, int removedCount) {
            // Regret-2优先处理“第二选择明显变差”的任务，避免先被普通任务抢走唯一窗口。
            List<GreedyAlgorithm.Task> pool = new ArrayList<>();
            for (GreedyAlgorithm.Task task : scenario.taskById.values()) {
                if (catalog.candidates(task.id).isEmpty()) continue;
                if (task.type == GreedyAlgorithm.TaskType.POINT && coveredPoints.contains(task.id)) continue;
                if (task.type == GreedyAlgorithm.TaskType.AREA
                        && areaSelections.getOrDefault(task.id, List.of()).size() >= MAX_AREA_STRIPS) continue;
                pool.add(task);
            }
            pool.sort(Comparator.comparingDouble((GreedyAlgorithm.Task t) -> -t.score));
            int poolLimit = scenario.taskById.size() <= 1_000 ? 120 : 60;
            if (pool.size() > poolLimit) pool = new ArrayList<>(pool.subList(0, poolLimit));
            int maxAdds = Math.min(Math.max(2, removedCount + 4), 32);

            for (int insertion = 0; insertion < maxAdds; insertion++) {
                RepairChoice chosen = null;
                for (GreedyAlgorithm.Task task : pool) {
                    if (task.type == GreedyAlgorithm.TaskType.POINT && coveredPoints.contains(task.id)) continue;
                    double best = -1, second = -1;
                    GreedyAlgorithm.Observation bestObservation = null;
                    int checked = 0;
                    for (GreedyAlgorithm.Observation candidate : catalog.candidates(task.id)) {
                        if (used.contains(candidate)) continue;
                        double gain = marginal(candidate, task, coveredPoints, areaSelections);
                        if (gain <= EPS) continue;
                        double value = gain / Math.max(1, candidate.duration());
                        if (value <= second) continue;
                        if (++checked > 32) break;
                        if (!canAdd(candidate, schedule)) continue;
                        if (value > best) {
                            second = best;
                            best = value;
                            bestObservation = candidate;
                        } else if (value > second) {
                            second = value;
                        }
                    }
                    if (bestObservation == null) continue;
                    double regret = second < 0 ? best : best - second;
                    double priority = regret + 0.20 * best;
                    if (chosen == null || priority > chosen.priority) {
                        chosen = new RepairChoice(task, bestObservation, priority);
                    }
                }
                if (chosen == null || !add(chosen.observation, schedule)) break;
                used.add(chosen.observation);
                coveredPoints.addAll(oracle.coveredPoints(chosen.observation));
                if (chosen.task.type == GreedyAlgorithm.TaskType.AREA) {
                    areaSelections.computeIfAbsent(chosen.task.id, k -> new ArrayList<>())
                            .add(chosen.observation);
                }
            }
        }

        private List<GreedyAlgorithm.Task> changeNeighborhood(
                List<GreedyAlgorithm.Task> source, Solution current, int destroy, int repair) {
            List<GreedyAlgorithm.Task> kept = new ArrayList<>(source);
            int orderDestroy = destroy % 3;
            int orderRepair = repair % 3;
            int q = Math.max(4, Math.min(kept.size() / 3,
                    (int) Math.round(kept.size() * (0.08 + random.nextDouble() * 0.18))));
            List<GreedyAlgorithm.Task> removed = new ArrayList<>();

            if (orderDestroy == 0) {
                Collections.shuffle(kept, random);
                for (int i = 0; i < q && !kept.isEmpty(); i++) removed.add(kept.remove(kept.size() - 1));
            } else if (orderDestroy == 1) {
                Map<GreedyAlgorithm.Task, Double> priorities = new IdentityHashMap<>();
                for (GreedyAlgorithm.Task task : kept) {
                    priorities.put(task, destructionPriority(task, current));
                }
                kept.sort(Comparator.comparingDouble(priorities::get));
                for (int i = 0; i < q && !kept.isEmpty(); i++) removed.add(kept.remove(0));
            } else {
                GreedyAlgorithm.Task seed = kept.get(random.nextInt(kept.size()));
                kept.sort(Comparator.comparingLong(t -> relatedness(seed, t)));
                for (int i = 0; i < q && !kept.isEmpty(); i++) removed.add(kept.remove(0));
            }

            if (orderRepair == 0) {
                removed.sort(Comparator.comparingDouble((GreedyAlgorithm.Task t) -> -catalog.taskPotential(t.id)));
            } else if (orderRepair == 1) {
                removed.sort(Comparator.comparingDouble((GreedyAlgorithm.Task t) ->
                        -catalog.taskPotential(t.id) / Math.max(1, catalog.candidates(t.id).size())));
            } else {
                Collections.shuffle(removed, random);
            }

            for (GreedyAlgorithm.Task task : removed) {
                int bound = Math.max(1, kept.size() / 2 + 1);
                int position = orderRepair == 2 ? random.nextInt(kept.size() + 1) : random.nextInt(bound);
                kept.add(position, task);
            }
            return kept;
        }

        private double destructionPriority(GreedyAlgorithm.Task task, Solution solution) {
            boolean covered = task.type == GreedyAlgorithm.TaskType.POINT
                    ? solution.pointCovered.contains(task.id)
                    : solution.areaRatios.getOrDefault(task.id, 0.0) > EPS;
            return (covered ? 1.0 : 0.0) * task.score + random.nextDouble() * 0.5;
        }

        private long relatedness(GreedyAlgorithm.Task a, GreedyAlgorithm.Task b) {
            return Math.abs((a.windowStart + a.windowEnd) - (b.windowStart + b.windowEnd))
                    + (a.type == b.type ? 0 : 3600);
        }

        private Solution construct(List<GreedyAlgorithm.Task> order, boolean randomized) {
            GreedyAlgorithm.Schedule schedule = emptySchedule();
            Set<String> coveredPoints = new HashSet<>();
            Map<String, List<GreedyAlgorithm.Observation>> areaSelections = new HashMap<>();
            Set<GreedyAlgorithm.Observation> used = Collections.newSetFromMap(new IdentityHashMap<>());

            for (GreedyAlgorithm.Task task : order) {
                if (task.type == GreedyAlgorithm.TaskType.POINT && coveredPoints.contains(task.id)) continue;
                GreedyAlgorithm.Observation chosen = chooseCandidate(
                        task, schedule, coveredPoints, areaSelections, used, randomized);
                if (chosen != null && add(chosen, schedule)) {
                    used.add(chosen);
                    coveredPoints.addAll(oracle.coveredPoints(chosen));
                    if (task.type == GreedyAlgorithm.TaskType.AREA) {
                        areaSelections.computeIfAbsent(task.id, k -> new ArrayList<>()).add(chosen);
                    }
                }
            }

            improveAreas(schedule, coveredPoints, areaSelections, used, randomized);
            return evaluate(schedule);
        }

        private GreedyAlgorithm.Observation chooseCandidate(
                GreedyAlgorithm.Task task, GreedyAlgorithm.Schedule schedule,
                Set<String> coveredPoints,
                Map<String, List<GreedyAlgorithm.Observation>> areaSelections,
                Set<GreedyAlgorithm.Observation> used, boolean randomized) {
            // 只保留单位时间边际收益最高的少量候选，再做严格可行性检查。
            // 这样避免每次重建都对数百条候选完整排序；候选本身仍来自官方姿态数据。
            List<ScoredCandidate> ranked = new ArrayList<>(CHOICE_POOL_SIZE);
            for (GreedyAlgorithm.Observation candidate : catalog.candidates(task.id)) {
                if (used.contains(candidate)) continue;
                double gain = marginal(candidate, task, coveredPoints, areaSelections);
                if (gain <= EPS) continue;
                ScoredCandidate scored = new ScoredCandidate(candidate,
                        gain / Math.max(1, candidate.duration()));
                int insert = 0;
                while (insert < ranked.size() && ranked.get(insert).value >= scored.value) insert++;
                if (insert < CHOICE_POOL_SIZE) {
                    ranked.add(insert, scored);
                    if (ranked.size() > CHOICE_POOL_SIZE) ranked.remove(ranked.size() - 1);
                }
            }
            int feasibleSeen = 0;
            List<GreedyAlgorithm.Observation> rcl = new ArrayList<>();
            for (ScoredCandidate x : ranked) {
                if (canAdd(x.observation, schedule)) {
                    rcl.add(x.observation);
                    feasibleSeen++;
                    if (!randomized || feasibleSeen >= RCL_SIZE) break;
                }
            }
            if (rcl.isEmpty()) return null;
            if (!randomized || rcl.size() == 1 || random.nextDouble() < 0.82) return rcl.get(0);
            int alternative = 1 + random.nextInt(rcl.size() - 1);
            return rcl.get(alternative);
        }

        private void improveAreas(GreedyAlgorithm.Schedule schedule, Set<String> coveredPoints,
                                  Map<String, List<GreedyAlgorithm.Observation>> areaSelections,
                                  Set<GreedyAlgorithm.Observation> used, boolean randomized) {
            // 区域任务允许最多MAX_AREA_STRIPS条带；每次只接受真正增加并集覆盖率的条带。
            List<GreedyAlgorithm.Task> tasks = new ArrayList<>(scenario.areaTasks);
            tasks.sort(Comparator.comparingDouble((GreedyAlgorithm.Task t) -> -t.score));
            for (GreedyAlgorithm.Task task : tasks) {
                while (areaSelections.getOrDefault(task.id, List.of()).size() < MAX_AREA_STRIPS) {
                    GreedyAlgorithm.Observation bestCandidate = null;
                    double bestDensity = 0;
                    for (GreedyAlgorithm.Observation candidate : catalog.candidates(task.id)) {
                        if (used.contains(candidate)) continue;
                        double gain = marginal(candidate, task, coveredPoints, areaSelections);
                        double density = gain / Math.max(1, candidate.duration());
                        if (density > bestDensity && canAdd(candidate, schedule)) {
                            bestDensity = density;
                            bestCandidate = candidate;
                        }
                    }
                    if (bestCandidate == null || bestDensity <= EPS) break;
                    if (randomized && random.nextDouble() < 0.08) break;
                    if (!add(bestCandidate, schedule)) break;
                    used.add(bestCandidate);
                    coveredPoints.addAll(oracle.coveredPoints(bestCandidate));
                    areaSelections.computeIfAbsent(task.id, k -> new ArrayList<>()).add(bestCandidate);
                }
            }
        }

        private double marginal(GreedyAlgorithm.Observation candidate, GreedyAlgorithm.Task task,
                                Set<String> coveredPoints,
                                Map<String, List<GreedyAlgorithm.Observation>> areaSelections) {
            // 一个候选的真实增益包括顺带覆盖点任务，以及区域任务并集覆盖率的增加。
            double gain = 0;
            for (String id : oracle.coveredPoints(candidate)) {
                if (!coveredPoints.contains(id)) gain += scenario.taskById.get(id).score;
            }
            if (task.type == GreedyAlgorithm.TaskType.AREA) {
                List<GreedyAlgorithm.Observation> before = areaSelections.getOrDefault(task.id, List.of());
                double oldRatio = oracle.areaRatio(task, before);
                List<GreedyAlgorithm.Observation> after = new ArrayList<>(before);
                after.add(candidate);
                double newRatio = oracle.areaRatio(task, after);
                gain += task.score * Math.max(0, newRatio - oldRatio);
            }
            return gain;
        }

        private GreedyAlgorithm.Polygon taskPolygon(GreedyAlgorithm.Task task) {
            return repo.areaTargets.get(task.targetId);
        }

        private boolean canAdd(GreedyAlgorithm.Observation observation, GreedyAlgorithm.Schedule schedule) {
            GreedyAlgorithm.Satellite sat = repo.satellites.get(observation.satelliteId);
            GreedyAlgorithm.SatelliteState state = schedule.satStates.get(observation.satelliteId);
            return feasibility.fitsObservation(observation, sat, state)
                    && feasibility.selectTransmission(observation, schedule, state) != null;
        }

        private boolean add(GreedyAlgorithm.Observation observation, GreedyAlgorithm.Schedule schedule) {
            GreedyAlgorithm.Satellite sat = repo.satellites.get(observation.satelliteId);
            GreedyAlgorithm.SatelliteState state = schedule.satStates.get(observation.satelliteId);
            if (!feasibility.fitsObservation(observation, sat, state)) return false;
            GreedyAlgorithm.Transmission tx = feasibility.selectTransmission(observation, schedule, state);
            if (tx == null) return false;
            state.observations.add(observation);
            state.observations.sort(Comparator.comparingLong(x -> x.start));
            state.orbitLoad[(int) (observation.start / 5400L)] += observation.duration();
            state.transmissions.add(tx);
            state.transmissions.sort(Comparator.comparingLong(x -> x.start));
            schedule.observations.add(observation);
            schedule.transmissions.add(tx);
            return true;
        }

        private GreedyAlgorithm.Schedule emptySchedule() {
            GreedyAlgorithm.Schedule schedule = new GreedyAlgorithm.Schedule();
            for (String satellite : scenario.resources) {
                schedule.satStates.put(satellite, new GreedyAlgorithm.SatelliteState());
            }
            return schedule;
        }

        private Solution evaluate(GreedyAlgorithm.Schedule schedule) {
            Set<String> pointCovered = new HashSet<>();
            Map<String, List<GreedyAlgorithm.Observation>> areaStrips = new HashMap<>();
            for (GreedyAlgorithm.Observation observation : schedule.observations) {
                pointCovered.addAll(oracle.coveredPoints(observation));
                GreedyAlgorithm.Task main = scenario.taskById.get(observation.taskId);
                if (main != null && main.type == GreedyAlgorithm.TaskType.AREA) {
                    areaStrips.computeIfAbsent(main.id, k -> new ArrayList<>()).add(observation);
                }
            }
            double score = 0;
            for (String id : pointCovered) score += scenario.taskById.get(id).score;
            Map<String, Double> areaRatios = new HashMap<>();
            for (GreedyAlgorithm.Task task : scenario.areaTasks) {
                List<GreedyAlgorithm.Observation> strips = areaStrips.get(task.id);
                if (strips == null) continue;
                double ratio = oracle.areaRatio(task, strips);
                if (ratio > EPS) {
                    areaRatios.put(task.id, ratio);
                    score += task.score * ratio;
                }
            }
            schedule.completedTaskIds = new HashSet<>(pointCovered);
            schedule.completedTaskIds.addAll(areaRatios.keySet());
            schedule.estimatedScore = score;
            return new Solution(schedule, score, pointCovered, areaRatios);
        }

        private int roulette(double[] weights) {
            double total = 0;
            for (double w : weights) total += w;
            double value = random.nextDouble() * total;
            for (int i = 0; i < weights.length; i++) {
                value -= weights[i];
                if (value <= 0) return i;
            }
            return weights.length - 1;
        }

        private void updateOperatorWeights() {
            updateWeights(destroyWeights, destroyScores, destroyUses);
            updateWeights(repairWeights, repairScores, repairUses);
        }

        private static void updateWeights(double[] weights, double[] scores, int[] uses) {
            for (int i = 0; i < weights.length; i++) {
                if (uses[i] > 0) {
                    double average = scores[i] / uses[i];
                    weights[i] = Math.max(0.20, 0.80 * weights[i] + 0.20 * average);
                }
                scores[i] = 0;
                uses[i] = 0;
            }
        }
    }

    private static final class CandidateCatalog {
        final GreedyAlgorithm.GreedySolver generator;
        final GreedyAlgorithm.Scenario scenario;
        final CoverageOracle oracle;
        final Map<String, List<GreedyAlgorithm.Observation>> candidates = new LinkedHashMap<>();
        final Map<String, Double> potentials = new HashMap<>();
        final Map<String, Integer> rawCounts = new HashMap<>();
        final Set<String> allReachablePoints = new HashSet<>();
        double optimisticUpper;

        CandidateCatalog(GreedyAlgorithm.GreedySolver generator,
                         GreedyAlgorithm.Scenario scenario, CoverageOracle oracle) {
            this.generator = generator;
            this.scenario = scenario;
            this.oracle = oracle;
        }

        void build() {
            // 候选压缩是大场景能运行的关键：先从官方姿态行构造合法候选，
            // 再按价值、原始顺序、时间和卫星多样性保留有限数量。
            int raw = 0;
            int kept = 0;
            for (GreedyAlgorithm.Task task : scenario.taskById.values()) {
                List<GreedyAlgorithm.Observation> all = generator.candidates(task);
                rawCounts.put(task.id, all.size());
                raw += all.size();
                int taskCount = scenario.taskById.size();
                int limit = task.type == GreedyAlgorithm.TaskType.POINT
                        ? (taskCount <= 500 ? 512 : taskCount <= 3_500 ? 64 : 24)
                        : (taskCount <= 500 ? 320 : taskCount <= 3_500 ? 64 : 32);
                List<GreedyAlgorithm.Observation> selected = diversify(all, limit, task);
                for (GreedyAlgorithm.Observation observation : selected) {
                    oracle.index(observation);
                    allReachablePoints.addAll(oracle.coveredPoints(observation));
                }
                candidates.put(task.id, selected);
                kept += selected.size();
                double best = 0;
                for (GreedyAlgorithm.Observation observation : selected) {
                    best = Math.max(best, intrinsic(observation, task));
                }
                potentials.put(task.id, best);
            }
            double reachablePointScore = allReachablePoints.stream()
                    .map(scenario.taskById::get).mapToDouble(t -> t.score).sum();
            double optimisticAreaScore = scenario.areaTasks.stream()
                    .filter(t -> !candidates(t.id).isEmpty()).mapToDouble(t -> t.score).sum();
            optimisticUpper = reachablePointScore + optimisticAreaScore;
            System.out.printf(Locale.ROOT,
                    "候选预处理：加载=%d，保留=%d；保留候选可覆盖点=%d/%d，候选乐观收益<=%.2f%n",
                    raw, kept, allReachablePoints.size(), scenario.pointTasks.size(),
                    optimisticUpper);
            generator.repo.retainOnlyCandidateAttitudes(candidates.values());
        }

        List<GreedyAlgorithm.Observation> candidates(String taskId) {
            return candidates.getOrDefault(taskId, List.of());
        }

        double taskPotential(String taskId) {
            return potentials.getOrDefault(taskId, 0.0);
        }

        int rawCount(String taskId) {
            return rawCounts.getOrDefault(taskId, 0);
        }

        private List<GreedyAlgorithm.Observation> diversify(
                List<GreedyAlgorithm.Observation> all, int limit, GreedyAlgorithm.Task task) {
            if (all.size() <= limit) return new ArrayList<>(all);
            List<GreedyAlgorithm.Observation> byValue = new ArrayList<>(all);
            byValue.sort(Comparator.comparingDouble((GreedyAlgorithm.Observation o) -> -intrinsic(o, task))
                    .thenComparingDouble(o -> Math.abs(o.roll) + Math.abs(o.pitch)));
            LinkedHashSet<GreedyAlgorithm.Observation> keep = new LinkedHashSet<>();
            for (int i = 0; i < Math.min(limit / 2, byValue.size()); i++) keep.add(byValue.get(i));

            int originalQuota = Math.max(1, limit / 4);
            for (int i = 0; i < originalQuota && i < all.size(); i++) {
                int index = originalQuota == 1 ? 0
                        : (int) Math.round(i * (all.size() - 1.0) / (originalQuota - 1.0));
                keep.add(all.get(index));
            }

            List<GreedyAlgorithm.Observation> byTime = new ArrayList<>(all);
            byTime.sort(Comparator.comparingLong(o -> o.start));
            int remaining = limit - keep.size();
            for (int i = 0; i < remaining && i < byTime.size(); i++) {
                int index = remaining == 1 ? byTime.size() / 2
                        : (int) Math.round(i * (byTime.size() - 1.0) / (remaining - 1.0));
                keep.add(byTime.get(index));
            }
            Map<String, GreedyAlgorithm.Observation> satelliteBest = new HashMap<>();
            for (GreedyAlgorithm.Observation observation : byValue) {
                satelliteBest.putIfAbsent(observation.satelliteId, observation);
            }
            for (GreedyAlgorithm.Observation observation : satelliteBest.values()) {
                if (keep.size() >= limit) break;
                keep.add(observation);
            }
            List<GreedyAlgorithm.Observation> result = new ArrayList<>(keep);
            if (result.size() > limit) result = new ArrayList<>(result.subList(0, limit));
            return result;
        }

        private double intrinsic(GreedyAlgorithm.Observation observation, GreedyAlgorithm.Task task) {
            double value = 0;
            for (String id : oracle.coveredPoints(observation)) value += scenario.taskById.get(id).score;
            if (task.type == GreedyAlgorithm.TaskType.AREA) {
                value += task.score * oracle.areaRatio(task, List.of(observation));
            }
            return value / Math.max(1, observation.duration());
        }
    }

    private static final class CoverageOracle {
        static final double CELL = 2.0;
        final GreedyAlgorithm.Repository repo;
        final GreedyAlgorithm.Scenario scenario;
        final Map<Long, List<GreedyAlgorithm.Task>> pointGrid = new HashMap<>();
        final Map<GreedyAlgorithm.Observation, Set<String>> pointCoverage = new IdentityHashMap<>();
        final Map<String, AreaGrid> areaGrids = new HashMap<>();

        CoverageOracle(GreedyAlgorithm.Repository repo, GreedyAlgorithm.Scenario scenario) {
            // 点任务使用经纬度网格快速索引；区域任务使用规则采样点的BitSet估计并集比例。
            this.repo = repo;
            this.scenario = scenario;
            for (GreedyAlgorithm.Task task : scenario.pointTasks) {
                GreedyAlgorithm.Point point = repo.pointTargets.get(task.targetId);
                if (point != null) pointGrid.computeIfAbsent(cell(point.x, point.y), k -> new ArrayList<>()).add(task);
            }
            for (GreedyAlgorithm.Task task : scenario.areaTasks) {
                GreedyAlgorithm.Polygon polygon = repo.areaTargets.get(task.targetId);
                if (polygon != null) areaGrids.put(task.id, new AreaGrid(polygon));
            }
        }

        void index(GreedyAlgorithm.Observation observation) {
            pointCoverage.computeIfAbsent(observation, this::compute);
        }

        Set<String> coveredPoints(GreedyAlgorithm.Observation observation) {
            return pointCoverage.computeIfAbsent(observation, this::compute);
        }

        double areaRatio(GreedyAlgorithm.Task task, List<GreedyAlgorithm.Observation> observations) {
            AreaGrid grid = areaGrids.get(task.id);
            if (grid == null || grid.samples.isEmpty()) return 0;
            BitSet union = new BitSet(grid.samples.size());
            for (GreedyAlgorithm.Observation observation : observations) {
                union.or(grid.coverage.computeIfAbsent(observation, grid::cover));
            }
            return (double) union.cardinality() / grid.samples.size();
        }

        private Set<String> compute(GreedyAlgorithm.Observation observation) {
            Set<String> result = new HashSet<>();
            if (observation.strip == null || observation.strip.size() < 3) return result;
            double minX = Double.POSITIVE_INFINITY, maxX = Double.NEGATIVE_INFINITY;
            double minY = Double.POSITIVE_INFINITY, maxY = Double.NEGATIVE_INFINITY;
            for (GreedyAlgorithm.Point p : observation.strip) {
                minX = Math.min(minX, p.x);
                maxX = Math.max(maxX, p.x);
                minY = Math.min(minY, p.y);
                maxY = Math.max(maxY, p.y);
            }
            if (maxX - minX > 180) {
                for (GreedyAlgorithm.Task task : scenario.pointTasks) check(observation, task, result);
                return result;
            }
            int x0 = gridX(minX), x1 = gridX(maxX), y0 = gridY(minY), y1 = gridY(maxY);
            for (int x = x0; x <= x1; x++) {
                for (int y = y0; y <= y1; y++) {
                    for (GreedyAlgorithm.Task task : pointGrid.getOrDefault(pack(x, y), List.of())) {
                        check(observation, task, result);
                    }
                }
            }
            return result;
        }

        private void check(GreedyAlgorithm.Observation observation, GreedyAlgorithm.Task task,
                           Set<String> result) {
            GreedyAlgorithm.Satellite satellite = repo.satellites.get(observation.satelliteId);
            if (satellite == null || satellite.resolution > task.resolution) return;
            if (observation.start < task.windowStart || observation.end > task.windowEnd) return;
            GreedyAlgorithm.Point point = repo.pointTargets.get(task.targetId);
            if (point == null || !inside(point, observation.strip)) return;
            if (satellite.type.equals("opt")) {
                long mid = (observation.start + observation.end) / 2;
                if (solarElevation(mid, point.y, point.x) < satellite.solarReq) return;
            }
            result.add(task.id);
        }

        private static boolean inside(GreedyAlgorithm.Point point, List<GreedyAlgorithm.Point> polygon) {
            boolean inside = false;
            for (int i = 0, j = polygon.size() - 1; i < polygon.size(); j = i++) {
                GreedyAlgorithm.Point a = polygon.get(i), b = polygon.get(j);
                if ((a.y > point.y) != (b.y > point.y)
                        && point.x < (b.x - a.x) * (point.y - a.y) / (b.y - a.y) + a.x) {
                    inside = !inside;
                }
            }
            return inside;
        }

        private static long cell(double lon, double lat) {
            return pack(gridX(lon), gridY(lat));
        }

        private static int gridX(double lon) {
            return (int) Math.floor((lon + 180.0) / CELL);
        }

        private static int gridY(double lat) {
            return (int) Math.floor((lat + 90.0) / CELL);
        }

        private static long pack(int x, int y) {
            return ((long) x << 32) ^ (y & 0xffffffffL);
        }

        private static double solarElevation(long seconds, double lat, double lon) {
            double days = (Instant.parse("2026-01-01T00:00:00Z").getEpochSecond()
                    - Instant.parse("2000-01-01T12:00:00Z").getEpochSecond() + seconds) / 86400.0;
            double meanLongitude = mod360(280.460 + 0.9856474 * days);
            double meanAnomaly = mod360(357.528 + 0.9856003 * days);
            double lambda = Math.toRadians(mod360(meanLongitude
                    + 1.915 * Math.sin(Math.toRadians(meanAnomaly))
                    + 0.020 * Math.sin(Math.toRadians(2 * meanAnomaly))));
            double obliquity = Math.toRadians(23.439 - 0.0000004 * days);
            double declination = Math.asin(Math.sin(obliquity) * Math.sin(lambda));
            double rightAscension = Math.atan2(Math.cos(obliquity) * Math.sin(lambda), Math.cos(lambda));
            double hourAngle = Math.toRadians(mod360(280.46061837 + 360.98564736629 * days) + lon)
                    - rightAscension;
            double latRad = Math.toRadians(lat);
            return Math.toDegrees(Math.asin(Math.sin(latRad) * Math.sin(declination)
                    + Math.cos(latRad) * Math.cos(declination) * Math.cos(hourAngle)));
        }

        private static double mod360(double value) {
            value %= 360.0;
            return value < 0 ? value + 360.0 : value;
        }

        private static final class AreaGrid {
            static final int N = 34;
            final List<GreedyAlgorithm.Point> samples = new ArrayList<>();
            final Map<GreedyAlgorithm.Observation, BitSet> coverage = new IdentityHashMap<>();

            AreaGrid(GreedyAlgorithm.Polygon polygon) {
                if (polygon.points.size() < 3) return;
                double minX = Double.POSITIVE_INFINITY, maxX = Double.NEGATIVE_INFINITY;
                double minY = Double.POSITIVE_INFINITY, maxY = Double.NEGATIVE_INFINITY;
                for (GreedyAlgorithm.Point p : polygon.points) {
                    minX = Math.min(minX, p.x);
                    maxX = Math.max(maxX, p.x);
                    minY = Math.min(minY, p.y);
                    maxY = Math.max(maxY, p.y);
                }
                for (int x = 0; x <= N; x++) {
                    for (int y = 0; y <= N; y++) {
                        GreedyAlgorithm.Point point = new GreedyAlgorithm.Point(
                                minX + (maxX - minX) * x / N,
                                minY + (maxY - minY) * y / N);
                        if (inside(point, polygon.points)) samples.add(point);
                    }
                }
            }

            BitSet cover(GreedyAlgorithm.Observation observation) {
                BitSet bits = new BitSet(samples.size());
                if (observation.strip == null || observation.strip.size() < 3) return bits;
                for (int i = 0; i < samples.size(); i++) {
                    if (inside(samples.get(i), observation.strip)) bits.set(i);
                }
                return bits;
            }
        }
    }

    private static GreedyAlgorithm.Schedule sortPairs(GreedyAlgorithm.Schedule source) {
        // 评分器要求观测行与对应数传行相邻；这里按观测开始时间整体排序但不拆开二元组。
        List<Integer> order = new ArrayList<>();
        for (int i = 0; i < source.observations.size(); i++) order.add(i);
        order.sort(Comparator.comparingLong(i -> source.observations.get(i).start));
        GreedyAlgorithm.Schedule sorted = new GreedyAlgorithm.Schedule();
        sorted.satStates = source.satStates;
        sorted.completedTaskIds = source.completedTaskIds;
        sorted.estimatedScore = source.estimatedScore;
        for (int i : order) {
            sorted.observations.add(source.observations.get(i));
            sorted.transmissions.add(source.transmissions.get(i));
        }
        return sorted;
    }

    private record ScoredCandidate(GreedyAlgorithm.Observation observation, double value) {
    }

    private record RepairChoice(GreedyAlgorithm.Task task,
                                GreedyAlgorithm.Observation observation, double priority) {
    }

    private record TaskOrderPolishResult(List<GreedyAlgorithm.Task> order,
                                         Solution solution) {
    }

    private record TaskChoice(GreedyAlgorithm.Task task,
                              GreedyAlgorithm.Observation observation,
                              double gain, double priority) {
    }

    private record GlobalChoice(GreedyAlgorithm.Task task,
                                GreedyAlgorithm.Observation observation,
                                double gain, double priority) {
    }

    private record EliteEntry(List<GreedyAlgorithm.Observation> observations,
                              double score) {
    }

    private record GraspResult(Solution solution,
                               List<GreedyAlgorithm.Task> order) {
    }

    private record Solution(GreedyAlgorithm.Schedule schedule, double score,
                            Set<String> pointCovered, Map<String, Double> areaRatios) {
    }
}

